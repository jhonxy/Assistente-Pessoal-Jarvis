// Testes de fluxos com DOM e mídia simulados. Não substituem um teste visual.
// Opcional para desenvolvedores: node test_frontend.cjs (sem dependências npm).
const vm = require('node:vm');
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
class Element {
  constructor() { this.children=[];this.dataset={};this.style={};this.attrs={};this.events={};this.checked=false;this.hidden=false;this.value='';this.textContent='';this.classList={toggle(){}}; }
  append(...nodes){this.children.push(...nodes);for(const n of nodes)if(n&&typeof n==='object')n.parent=this;}
  prepend(node){this.children.unshift(node);node.parent=this;}
  replaceChildren(...nodes){this.children=nodes;}
  remove(){if(this.parent)this.parent.children=this.parent.children.filter(x=>x!==this);}
  get firstChild(){return this.children[0];} get lastChild(){return this.children.at(-1);}
  addEventListener(name,fn){this.events[name]=fn;} removeEventListener(name){delete this.events[name];}
  setAttribute(name,val){this.attrs[name]=val;} removeAttribute(name){delete this.attrs[name];}
  showModal(){this.open=true;} close(){this.open=false;this.events.close?.();}
  pause(){} load(){}
  play(){playCalls++;this.onplay?.();setImmediate(()=>this.onended?.());return Promise.resolve();}
  focus(){} click(){this.onclick?.();} querySelectorAll(){return [];} setPointerCapture(){}
}
const elements=new Map();
const get=id=>{if(!elements.has(id))elements.set(id,new Element());return elements.get(id);};
const requests=[], timers=new Set();
const localStorage=new Map();
let getMedia, playCalls=0;
const sandbox={console, URLSearchParams, AbortController, Blob, TextEncoder, atob:s=>Buffer.from(s,'base64').toString('binary'),
  location:{hash:'#token=test-session'},history:{replaceState(){}},
  sessionStorage:{getItem:k=>localStorage.get(k),setItem:(k,v)=>localStorage.set(k,v),removeItem:k=>localStorage.delete(k)},
  localStorage:{getItem:k=>localStorage.get(k)??null,setItem:(k,v)=>localStorage.set(k,v),removeItem:k=>localStorage.delete(k)},
  document:{getElementById:get,createElement:()=>new Element(),createTextNode:text=>({textContent:text}),
    querySelectorAll:()=>[],body:new Element(),addEventListener(){},hidden:false},
  navigator:{mediaDevices:{getUserMedia:opts=>getMedia(opts)},clipboard:{writeText:async()=>{}}},
  crypto:{randomUUID:()=>String(Math.random()).slice(2)},confirm:()=>true,
  performance:{now:()=>100},requestAnimationFrame:()=>1,cancelAnimationFrame(){},
  setTimeout:(fn,ms)=>{const t=setTimeout(fn,ms);timers.add(t);return t;},clearTimeout,
  setInterval:()=>0,clearInterval(){},URL:{createObjectURL:()=>'',revokeObjectURL(){}},
  window:{addEventListener(){}},AudioContext:class {async resume(){} async close(){} createMediaStreamSource(){return{connect(){}};}createAnalyser(){return{fftSize:1024,getFloatTimeDomainData(){}};}},
  fetch:async(url,opts)=>{requests.push({url,opts});let data={};if(url.endsWith('/status'))data={online:false,has_key:false,model:'gemini-3.5-flash-lite',remember_key:false};if(url.endsWith('/board'))data={cards:[]};if(url.endsWith('/speak'))data={audio:Buffer.from('RIFF-test').toString('base64'),mime:'audio/wav'};if(url.endsWith('/chat'))data={answer:'Resposta simulada',source:'online'};if(url.endsWith('/whatsapp'))data={url:'https://wa.me/5531999999999?text=oi'};return {ok:true,json:async()=>data};}
};
class Recorder {
  static isTypeSupported(){return true;}
  constructor(){this.state='inactive';}
  start(){this.state='recording';}
  stop(){this.state='inactive';Promise.resolve().then(()=>this.onstop?.());}
}
sandbox.MediaRecorder=Recorder;sandbox.window.MediaRecorder=Recorder;
const ctx=vm.createContext(sandbox);
vm.runInContext(fs.readFileSync(path.join(__dirname,'web/app.js'),'utf8'),ctx);
const run=code=>vm.runInContext(code,ctx);
const tick=()=>new Promise(resolve=>setImmediate(resolve));
(async()=>{
 await tick();
 // Offline microphone must open settings without requesting permission or billing.
 let calls=0;getMedia=async()=>{calls++;throw new Error('not expected');};
 await run('startRecording()');assert.equal(calls,0);assert.equal(get('settingsDialog').open,true);
 // A late device permission after Pause must close the newly acquired track.
 let resolveDevice,stopped=0;getMedia=()=>new Promise(resolve=>resolveDevice=resolve);
 run('state.online=true');const acquiring=run('startRecording()');run('stopVoice()');
 resolveDevice({getTracks:()=>[{stop:()=>stopped++}]});await acquiring;
 assert.equal(stopped,1);assert.equal(run('state.recording'),false);
 // Stop while recording must discard audio and avoid a transcription request.
 getMedia=async()=>({getTracks:()=>[{stop:()=>stopped++}]});
 await run('startRecording()');assert.equal(run('state.recording'),true);run('stopVoice()');await tick();
 assert.equal(run('state.recording'),false);assert.equal(run('state.recorder'),null);
 assert.equal(requests.filter(r=>r.url.endsWith('/transcribe')).length,0);
 // AI output is placed as text rather than executable markup.
 run('addMessage("assistant", "<img src=x onerror=alert(1)>", "online")');
 assert.equal(get('chat').lastChild.children[1].textContent,'<img src=x onerror=alert(1)>');
 // Single chat send sends only the explicitly attached image, then removes it.
 run('state.pendingPhoto="data:image/jpeg;base64,test"');await run('sendMessage("Descreva")');
 const sent=requests.filter(r=>r.url.endsWith('/chat')).at(-1);
 assert.equal(JSON.parse(sent.opts.body).image,'data:image/jpeg;base64,test');assert.equal(run('state.pendingPhoto'),null);
 // Editing a prepared WhatsApp draft invalidates the old link.
 get('phone').value='5531999999999';get('waText').value='oi';await get('whatsappForm').onsubmit({preventDefault(){}});
 assert.equal(get('waLink').hidden,false);get('waText').oninput();assert.equal(get('waLink').hidden,true);
 assert.equal(localStorage.size,1);assert.equal(localStorage.get('jarvisToken'),'test-session');
 // New synthetic voice playback must finish and release the busy state.
 run('state.online=true;state.speechEngine="gemini"');
 await run('playAnswer("Olá, João.")');
 assert.equal(playCalls,1);assert.equal(run('state.busy'),false);assert.equal(run('state.speaking'),false);
 const realFetch=sandbox.fetch;let releaseVoice;
 sandbox.fetch=(url,opts)=>url.endsWith('/speak')?new Promise(resolve=>releaseVoice=resolve):realFetch(url,opts);
 const pending=run('playAnswer("Não deve tocar depois de pausar")');
 await tick();run('stopVoice()');
 releaseVoice({ok:true,json:async()=>({audio:Buffer.from('RIFF-test').toString('base64')})});await pending;
 assert.equal(playCalls,1);assert.equal(run('state.busy'),false);
 // Quota error must stop continuous mode without retrying or using a paid provider.
 let speechRequests=0;
 sandbox.fetch=async(url,opts)=>{if(url.endsWith('/speak')){speechRequests++;return{ok:false,json:async()=>({error:'Cota atingida'})};}return realFetch(url,opts);};
 run('state.continuous=true');await run('speak("Teste de limite",state.epoch)');
 assert.equal(speechRequests,1);assert.equal(run('state.continuous'),false);
 // Detecting models repopulates the list and keeps the model the server chose.
 sandbox.fetch=async(url,opts)=>{if(url.endsWith('/models'))return{ok:true,json:async()=>({models:['gemini-3.5-flash-lite','gemini-3.6-flash'],model:'gemini-3.6-flash'})};return realFetch(url,opts);};
 await get('detectModelsBtn').onclick();
 assert.deepEqual(get('modelName').children.map(o=>o.value),['gemini-3.5-flash-lite','gemini-3.6-flash']);
 assert.equal(get('modelName').value,'gemini-3.6-flash');
 assert.equal(run('state.busy'),false);
 // Saving settings must forward the "remember key" choice to the local service.
 sandbox.fetch=realFetch;get('rememberKey').checked=true;
 await run('saveSettings(false)');
 assert.equal(JSON.parse(requests.filter(r=>r.url.endsWith('/settings')).at(-1).opts.body).remember_key,true);
 // A stale session code must be discarded with an instruction instead of a generic failure.
 sandbox.fetch=async()=>({ok:false,status:403,json:async()=>({error:'Sessão inválida.'})});
 await assert.rejects(run('api("status")'),/Iniciar\.bat/);
 assert.equal(localStorage.size,0);
 console.log('12 fluxos JavaScript passaram, incluindo reprodução da voz Gemini, descarte após Pausar e erro de cota sem repetição.');

})().catch(e=>{console.error(e);process.exitCode=1;}).finally(()=>{for(const timer of timers)clearTimeout(timer);});
