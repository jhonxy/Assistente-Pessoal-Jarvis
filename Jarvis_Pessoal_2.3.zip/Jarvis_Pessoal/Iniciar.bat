@echo off
chcp 65001 >nul
cd /d "%~dp0"
where py >nul 2>nul
if not errorlevel 1 (
    py -3 app.py
) else (
    python app.py
)
if errorlevel 1 (
    echo.
    echo Nao foi possivel iniciar. Instale Python 3 e tente novamente.
    echo Guia: LEIA_PRIMEIRO.md
    pause
)
