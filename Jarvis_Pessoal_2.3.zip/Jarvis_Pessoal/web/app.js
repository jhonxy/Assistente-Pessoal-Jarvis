'use strict';
const $ = id => document.getElementById(id);
const tokenFromURL = new URLSearchParams(location.hash.slice(1)).get('token');
const store = { read() { try { return localStorage.getItem('jarvisToken') || sessionStorage.getItem('jarvisToken') || ''; } catch { return ''; } },
  write(value) { try { localStorage.setItem('jarvisToken', value); } catch { try { sessionStorage.setItem('jarvisToken', value); } catch {} } },
  clear() { try { localStorage.removeItem('jarvisToken'); } catch {} try { sessionStorage.removeItem('jarvisToken'); } catch {} } };
if (tokenFromURL) { store.write(tokenFromURL); history.replaceState(null, '', '/'); }
const token = store.read();
const state = { online: false, busy: false, recording: false, acquiring: false, speaking: false,
  camera: null, mic: null, recorder: null, audioContext: null, vadFrame: null,
  epoch: 0, continuous: false, nextTurn: null, speechDone: null, pendingPhoto: null,
  cards: [], boardReady: false, boardQueue: Promise.resolve(), boardRevision: 0, editing: null,
  lastAnswer: '', voice: '', provider: 'gemini', chat: [], speechEngine: 'gemini', geminiVoice: 'Charon', speechRun: 0, audioUrl: null };
let toastTimer;
function toast(text) { $('toast').textContent = text; $('toast').hidden = false; clearTimeout(toastTimer); toastTimer = setTimeout(() => { $('toast').hidden = true; }, 6500); }
function log(text) {
  const line = document.createElement('li'), time = document.createElement('time');
  time.textContent = new Date().toLocaleTimeString('pt-BR', {hour:'2-digit',minute:'2-digit',second:'2-digit'});
  line.append(time, document.createTextNode(text)); $('activityLog').prepend(line);
  while ($('activityLog').children.length > 20) $('activityLog').lastChild.remove();
}
async function api(path, body, rawType) {
  const controller = new AbortController(), timeout = setTimeout(() => controller.abort(), 75000);
  try {
    const response = await fetch('/api/' + path, {method: body === undefined ? 'GET' : 'POST',
      headers: {'X-Jarvis-Token': token, ...(body === undefined ? {} : {'Content-Type': rawType || 'application/json'})},
      body: body === undefined ? undefined : rawType ? body : JSON.stringify(body), signal: controller.signal});
    const data = await response.json();
    if (response.status === 403) {
      store.clear();
      throw new Error('Sessão inválida. Feche esta janela, rode o Iniciar.bat e abra o endereço completo que aparece no terminal, com a parte #token=.');
    }
    if (!response.ok) throw new Error(data.error || 'Não foi possível concluir a tarefa.');
    return data;
  } catch (error) {
    if (error.name === 'AbortError') throw new Error('A tarefa demorou demais. Aguarde alguns segundos e tente novamente.');
    if (error instanceof TypeError) throw new Error('O Jarvis local não respondeu. Confira se a janela do Iniciar.bat continua aberta.');
    throw error;
  } finally { clearTimeout(timeout); }
}
function setPhase(phase, hint) {
  const labels = {idle:'PRONTO',listening:'ESCUTANDO',thinking:'PROCESSANDO',speaking:'FALANDO',paused:'PAUSADO'};
  $('reactor').dataset.state = phase; $('stateName').textContent = labels[phase];
  $('stateHint').textContent = hint || 'Digite no chat ou clique em Falar.';
  document.body.classList.toggle('voice-active', ['listening','speaking'].includes(phase));
}
function controls() {
  $('sendBtn').disabled = state.busy || state.recording || state.acquiring;
  $('micBtn').disabled = state.busy || state.acquiring || Boolean(state.recorder && !state.recording);
  $('micBtn').textContent = state.recording ? '■  Terminar fala' : '◉  Falar';
  $('clearBtn').disabled = state.busy;
  $('settingsBtn').disabled = state.busy;
  for (const id of ['testVoiceBtn','testConnectionBtn','detectModelsBtn','forgetKeyBtn','applySettingsBtn']) $(id).disabled = state.busy;
  $('visionBtn').disabled = !state.camera || state.busy || state.recording;
  $('autoConversation').checked = state.continuous;
  $('privacyStatus').textContent = (state.recording ? 'Microfone gravando' : 'Microfone desligado') + ' · ' + (state.camera ? 'Câmera ligada' : 'Câmera desligada');
}
function addMessage(role, text, source='') {
  const item = document.createElement('article'); item.className = 'message ' + role;
  const title = document.createElement('div'); title.className = 'author';
  title.textContent = role === 'user' ? 'VOCÊ' : role === 'error' ? 'AVISO' : 'JARVIS';
  if (source) { const label = document.createElement('span'); label.className = 'source'; label.textContent = source === 'online' ? 'IA ONLINE' : 'LOCAL'; title.append(label); }
  const body = document.createElement('div'); body.className = 'body'; body.textContent = text;
  item.append(title, body);
  if (role === 'assistant') {
    state.lastAnswer = text;
    const bar = document.createElement('div'); bar.className = 'message-actions';
    for (const [label, fn] of [['Copiar', async () => { try { await navigator.clipboard.writeText(text); toast('Texto copiado.'); } catch { toast('Selecione o texto e use Ctrl+C.'); } }],
      ['Fixar no quadro', () => { addCard({title:'Resposta do Jarvis',text}); }],
      ['Ouvir', () => playAnswer(text)],
      ['Salvar .txt', () => download('resposta_jarvis.txt', text, 'text/plain;charset=utf-8')]]) {
      const button = document.createElement('button'); button.textContent = label; button.addEventListener('click', fn); bar.append(button);
    }
    item.append(bar);
  }
  $('chat').append(item); $('chat').scrollTop = $('chat').scrollHeight;
  state.chat.push({role,text});
  while ($('chat').children.length > 100) $('chat').firstChild.remove();
  if (state.chat.length > 100) state.chat.shift();
}
async function sendMessage(text, epoch=state.epoch) {
  text = text.trim();
  if (!text || state.busy || state.recording || state.acquiring) return;
  if (text.length > 12000) return toast('Use até 12.000 caracteres por mensagem.');
  cancelSpeech(); clearTimeout(state.nextTurn);
  const image = state.pendingPhoto; removePhoto();
  $('message').value = ''; addMessage('user', text + (image ? '\n[Foto anexada]' : ''));
  state.busy = true; controls(); setPhase('thinking', image ? 'Analisando a foto que você enviou…' : 'Preparando sua resposta…');
  let success = false;
  try {
    const result = await api('chat', {text, ...(image ? {image} : {})});
    addMessage('assistant', result.answer, result.source); log(image ? 'Análise da foto concluída.' : 'Resposta recebida.');
    if (result.action === 'whatsapp') { stopVoice(); openWhatsApp(); }
    if ($('readAloud').checked && epoch === state.epoch) await speak(result.answer, epoch);
    success = true;
  } catch (error) { addMessage('error', error.message); log('A tarefa encontrou um erro.'); stopVoice(); }
  finally {
    state.busy = false; controls(); setPhase('idle');
    if (success && state.continuous && epoch === state.epoch) state.nextTurn = setTimeout(startRecording, 700);
  }
}
function voices() {
  if (!('speechSynthesis' in window)) return;
  const list = speechSynthesis.getVoices().filter(v => v.lang.toLowerCase().startsWith('pt'));
  const selected = $('voiceSelect').value; $('voiceSelect').replaceChildren();
  const placeholder = document.createElement('option'); placeholder.value = ''; placeholder.textContent = 'Voz padrão em português'; $('voiceSelect').append(placeholder);
  for (const voice of list) { const opt = document.createElement('option'); opt.value = voice.voiceURI; opt.textContent = voice.name + (voice.localService ? ' · local' : ' · online'); $('voiceSelect').append(opt); }
  $('voiceSelect').value = selected;
}
function cancelSpeech() {
  state.speechRun++;
  if ('speechSynthesis' in window) speechSynthesis.cancel();
  state.speaking = false;
  if (state.speechDone) { const finish = state.speechDone; state.speechDone = null; finish(); }
  const player = $('voicePlayer');
  player.onended = player.onerror = player.onplay = player.onpause = null;
  player.pause(); player.removeAttribute('src'); player.load(); $('voicePlayback').hidden = true;
  if (state.audioUrl) { URL.revokeObjectURL(state.audioUrl); state.audioUrl = null; }
}
async function speak(text, epoch) {
  if (epoch !== state.epoch) return;
  if (state.speechEngine !== 'gemini' || !state.online) return speakSystem(text, epoch);
  cancelSpeech();
  const run = state.speechRun;
  setPhase('thinking', 'Preparando a voz do Jarvis…');
  let clean = text.replace(/[#*`]/g, '').trim();
  if (clean.length > 1500) { clean = clean.slice(0, 1440) + '. O restante está disponível no chat.'; toast('A voz Gemini lerá o início. Para ouvir tudo, selecione Voz do sistema.'); }
  try {
    const result = await api('speak', {text: clean});
    if (epoch !== state.epoch || run !== state.speechRun) return;
    const bytes = Uint8Array.from(atob(result.audio), char => char.charCodeAt(0));
    state.audioUrl = URL.createObjectURL(new Blob([bytes], {type:'audio/wav'}));
    const player = $('voicePlayer'); player.src = state.audioUrl; $('voicePlayback').hidden = false;
    await new Promise(resolve => {
      let done = false;
      const finish = () => { if (done) return; done = true; clearTimeout(timeout); state.speechDone = null; state.speaking = false; resolve(); };
      const timeout = setTimeout(() => { player.pause(); state.continuous = false; controls(); finish(); }, 180000);
      state.speechDone = finish;
      player.onplay = () => { state.speaking = true; setPhase('speaking', 'Voz gerada por IA. Use Parar voz para interromper.'); };
      player.onended = () => { state.speaking = false; setPhase('idle'); finish(); };
      player.onpause = () => { if (!player.ended) { state.speaking = false; state.continuous = false; controls(); setPhase('idle'); finish(); } };
      player.onerror = () => { state.speaking = false; toast('Não foi possível reproduzir o áudio. Use Voz do sistema.'); state.continuous = false; controls(); finish(); };
      player.play().catch(() => { state.continuous = false; controls(); setPhase('idle', 'Clique em play no áudio abaixo do chat.'); toast('O navegador bloqueou o áudio automático. Clique no botão play do áudio.'); finish(); });
    });
  } catch (error) {
    if (epoch !== state.epoch || run !== state.speechRun) return;
    state.continuous = false; controls();
    toast(error.message + ' Tentando a voz instalada.'); log('Voz Gemini indisponível. Sem troca para serviço pago.');
    await speakSystem(text, epoch);
  }
  if (epoch === state.epoch && !state.recording) setPhase('idle');
}
async function playAnswer(text) {
  if (state.busy || state.recording || state.acquiring) return toast('Aguarde a tarefa atual terminar.');
  stopVoice(); state.busy = true; controls();
  try { await speak(text, state.epoch); }
  finally { state.busy = false; controls(); }
}
async function speakSystem(text, epoch) {
  if (!('speechSynthesis' in window) || epoch !== state.epoch) return;
  cancelSpeech();
  const list = speechSynthesis.getVoices();
  const voice = list.find(v => v.voiceURI === state.voice) || list.find(v => v.lang === 'pt-BR' && v.localService) || list.find(v => v.lang.toLowerCase().startsWith('pt'));
  if (!voice) { toast('Nenhuma voz em português encontrada. Instale uma voz de fala do Windows nas configurações de idioma.'); return; }
  state.speaking = true; setPhase('speaking', 'Você pode interromper em Parar voz.');
  const chunks = text.replace(/[#*`]/g, '').match(/.{1,240}(?:\s|$)|.{1,240}/gs) || [];
  for (const chunk of chunks) {
    if (!state.speaking || epoch !== state.epoch) break;
    await new Promise(resolve => {
      let settled = false;
      const finish = () => { if (settled) return; settled = true; clearTimeout(timeout); state.speechDone = null; resolve(); };
      const utterance = new SpeechSynthesisUtterance(chunk);
      utterance.lang = 'pt-BR'; utterance.voice = voice; utterance.rate = 1.02;
      utterance.onend = finish;
      utterance.onerror = event => { if (!['canceled','interrupted'].includes(event.error)) { toast('Não foi possível ler a resposta. Confira a voz selecionada.'); state.speaking = false; } finish(); };
      const timeout = setTimeout(() => { speechSynthesis.cancel(); state.speaking = false; finish(); }, 45000);
      state.speechDone = finish; speechSynthesis.speak(utterance);
    });
  }
  state.speaking = false;
  if (!state.recording) setPhase('idle');
}
function stopVoice() {
  state.continuous = false; state.epoch++; clearTimeout(state.nextTurn); cancelSpeech();
  if (state.recorder && state.recorder.state === 'recording') { state.recorder.discard = true; state.recorder.stop(); }
  cleanupMic(); controls(); setPhase(state.busy ? 'thinking' : 'idle', state.busy ? 'A tarefa enviada ainda está em andamento.' : undefined);
}
function cleanupMic() {
  cancelAnimationFrame(state.vadFrame); state.vadFrame = null;
  if (state.mic) state.mic.getTracks().forEach(track => track.stop());
  state.mic = null;
  if (state.audioContext) state.audioContext.close().catch(() => {});
  state.audioContext = null; state.recording = false;
}
async function startRecording() {
  if (state.busy || state.recording || state.acquiring || state.recorder) return;
  if (!state.online) { stopVoice(); toast('Ative a IA online para transcrever sua fala.'); $('settingsDialog').showModal(); return; }
  if (!navigator.mediaDevices?.getUserMedia || !window.MediaRecorder) { stopVoice(); toast('Use Edge ou Chrome para acessar o microfone.'); return; }
  const epoch = state.epoch; state.acquiring = true; controls(); cancelSpeech(); setPhase('listening','Aguardando acesso ao microfone…');
  let ownStream;
  try {
    ownStream = await navigator.mediaDevices.getUserMedia({audio:{echoCancellation:true,noiseSuppression:true},video:false});
    if (epoch !== state.epoch) { ownStream.getTracks().forEach(t => t.stop()); return; }
    const mime = ['audio/webm;codecs=opus','audio/webm','audio/ogg;codecs=opus'].find(t => MediaRecorder.isTypeSupported(t));
    if (!mime) throw new Error('Formato de áudio não suportado. Abra pelo Edge ou Chrome.');
    state.mic = ownStream;
    const recorder = new MediaRecorder(ownStream, {mimeType:mime}); state.recorder = recorder;
    const chunks = []; recorder.discard = false;
    recorder.ondataavailable = event => { if (event.data.size) chunks.push(event.data); };
    recorder.onerror = () => { recorder.discard = true; stopVoice(); toast('A gravação falhou. Confira seu microfone.'); };
    recorder.onstop = async () => {
      cleanupMic(); state.recorder = null; controls();
      if (recorder.discard || epoch !== state.epoch) { setPhase(state.busy ? 'thinking' : 'idle'); return; }
      state.busy = true; controls(); setPhase('thinking', 'Transformando sua fala em texto…');
      let transcript;
      try {
        const blob = new Blob(chunks, {type:mime});
        const result = await api('transcribe', await blob.arrayBuffer(), mime);
        if (epoch === state.epoch) transcript = result.text;
      } catch(error) { addMessage('error', error.message); stopVoice(); }
      finally { state.busy = false; controls(); setPhase('idle'); }
      if (transcript) await sendMessage(transcript, epoch);
    };
    const audioContext = new AudioContext(); state.audioContext = audioContext;
    await audioContext.resume();
    if (epoch !== state.epoch) { recorder.discard = true; cleanupMic(); return; }
    const source = audioContext.createMediaStreamSource(ownStream), analyser = audioContext.createAnalyser();
    analyser.fftSize = 1024; source.connect(analyser); const samples = new Float32Array(analyser.fftSize);
    let start = performance.now(), lastVoice = start, heard = false, voicedFrames = 0;
    function detect(now) {
      if (recorder.state !== 'recording') return;
      analyser.getFloatTimeDomainData(samples);
      let total = 0; for (const value of samples) total += value * value;
      if (Math.sqrt(total / samples.length) > .018) { lastVoice = now; voicedFrames++; if (voicedFrames > 4) heard = true; }
      if (now - start > 45000 || (state.continuous && heard && now - lastVoice > 1500)) { recorder.stop(); return; }
      if (state.continuous && !heard && now - start > 10000) { recorder.discard = true; stopVoice(); toast('Nenhuma fala detectada. A escuta foi encerrada.'); return; }
      state.vadFrame = requestAnimationFrame(detect);
    }
    recorder.start(250); state.recording = true; log('Microfone ativado.');
    setPhase('listening', state.continuous ? 'Fale. Uma pausa encerra a gravação.' : 'Fale e clique em Terminar fala. Máximo: 45 s.');
    state.vadFrame = requestAnimationFrame(detect);
  } catch(error) {
    if (ownStream) ownStream.getTracks().forEach(t => t.stop());
    stopVoice(); toast(error.name === 'NotAllowedError' ? 'Microfone bloqueado. Permita o acesso nas configurações do navegador.' : error.name === 'NotFoundError' ? 'Nenhum microfone encontrado.' : error.message);
  } finally { state.acquiring = false; controls(); }
}
async function toggleCamera() {
  if (state.camera) { stopCamera(); return; }
  $('cameraBtn').disabled = true;
  const epoch = state.epoch;
  try {
    const stream = await navigator.mediaDevices.getUserMedia({video:{width:{ideal:640},height:{ideal:360},frameRate:{ideal:15,max:20}},audio:false});
    if (epoch !== state.epoch) { stream.getTracks().forEach(t => t.stop()); return; }
    state.camera = stream; $('camera').srcObject = stream; $('camera').hidden = false; $('cameraEmpty').hidden = true;
    await $('camera').play(); $('cameraBtn').textContent = 'Desligar'; $('cameraStatus').textContent = 'PRÉVIA LOCAL'; log('Prévia da câmera ativada.');
    stream.getVideoTracks()[0].addEventListener('ended', stopCamera);
  } catch(error) { stopCamera(); toast(error.name === 'NotAllowedError' ? 'Câmera bloqueada. Permita o acesso no navegador.' : 'Não foi possível abrir a câmera. Confira se outro programa está usando ela.'); }
  finally { $('cameraBtn').disabled = false; controls(); }
}
function stopCamera() {
  if (state.camera) state.camera.getTracks().forEach(t => t.stop());
  state.camera = null; $('camera').srcObject = null; $('camera').hidden = true; $('cameraEmpty').hidden = false;
  $('cameraBtn').textContent = 'Ligar câmera'; $('cameraStatus').textContent = 'DESLIGADA'; controls();
}
function preparePhoto() {
  if (!state.camera || !$('camera').videoWidth) return toast('Aguarde a câmera carregar.');
  if (!state.online) { stopVoice(); toast('Ative a IA online antes de analisar fotos.'); $('settingsDialog').showModal(); return; }
  stopVoice();
  const canvas = document.createElement('canvas'); canvas.width = $('camera').videoWidth; canvas.height = $('camera').videoHeight;
  canvas.getContext('2d').drawImage($('camera'),0,0); state.pendingPhoto = canvas.toDataURL('image/jpeg',.78);
  $('pendingImageThumb').src = state.pendingPhoto; $('pendingImage').hidden = false;
  $('message').value = 'Descreva o que aparece nesta foto.'; $('message').focus(); toast('Foto pronta. Revise a pergunta e clique em Enviar.');
}
function removePhoto() { state.pendingPhoto = null; $('pendingImage').hidden = true; $('pendingImageThumb').removeAttribute('src'); }
function showTab(board) {
  $('assistantView').hidden = board; $('boardView').hidden = !board;
  $('boardTab').classList.toggle('active',board); $('assistantTab').classList.toggle('active',!board);
  $('boardTab').setAttribute('aria-selected',String(board)); $('assistantTab').setAttribute('aria-selected',String(!board));
}
function download(name,text,type) {
  const url = URL.createObjectURL(new Blob([text],{type})), link = document.createElement('a'); link.href = url; link.download = name; link.click(); setTimeout(() => URL.revokeObjectURL(url),2000);
}
function saveBoard() {
  if (!state.boardReady) return;
  const revision = ++state.boardRevision, snapshot = JSON.parse(JSON.stringify(state.cards)); $('saveStatus').textContent = 'Salvando…';
  state.boardQueue = state.boardQueue.catch(() => {}).then(async () => {
    try { await api('board',{cards:snapshot}); if (revision === state.boardRevision) $('saveStatus').textContent = 'Salvo neste PC'; }
    catch(error) { if (revision === state.boardRevision) $('saveStatus').textContent = 'Falha ao salvar · exporte uma cópia'; toast(error.message); }
  });
}
function addCard(card) {
  if (!state.boardReady) return toast('O quadro não está disponível. Reabra o aplicativo.');
  if (state.cards.length >= 30) return toast('O quadro aceita até 30 cartões.');
  const index = state.cards.length;
  state.cards.push({id:crypto.randomUUID(), title:'Nova ideia',text:'', x:30+(index%4)*325,y:30+Math.floor(index/4)*350,...card});
  renderBoard(); saveBoard(); toast('Cartão adicionado ao quadro.');
}
function renderBoard() {
  $('boardCanvas').querySelectorAll('.board-card').forEach(node => node.remove());
  $('boardEmpty').hidden = state.cards.length > 0; $('cardCount').textContent = state.cards.length;
  let width=1500,height=1000;
  for (const card of state.cards) {
    const article = document.createElement('article'); article.className = 'board-card'; article.style.left = card.x+'px'; article.style.top = card.y+'px';
    const head = document.createElement('div'); head.className = 'card-head'; head.tabIndex=0; head.title='Arraste para mover; use as setas do teclado quando selecionado.';
    const title = document.createElement('strong'); title.textContent = card.title;
    const actions=document.createElement('div'); actions.className='card-tools';
    const edit=document.createElement('button'); edit.textContent='✎'; edit.setAttribute('aria-label','Editar '+card.title); edit.onclick=()=>openCard(card);
    const remove=document.createElement('button'); remove.textContent='×'; remove.setAttribute('aria-label','Excluir '+card.title);
    remove.onclick=()=>{ if(confirm('Excluir este cartão do quadro?')){state.cards=state.cards.filter(c=>c.id!==card.id);renderBoard();saveBoard();} };
    actions.append(edit,remove);head.append(title,actions);
    const content=document.createElement('div');content.className='card-content';
    if(card.image){const im=document.createElement('img');im.src=card.image;im.alt=card.title;content.append(im);}
    content.append(document.createTextNode(card.text));article.append(head,content);$('boardCanvas').append(article);
    head.addEventListener('pointerdown',e=>{
      if(e.target.closest('button'))return;
      e.preventDefault();head.setPointerCapture(e.pointerId);head.focus();
      const initialX=e.clientX,initialY=e.clientY,x=card.x,y=card.y;article.style.zIndex='5';
      const move=event=>{card.x=Math.round(Math.max(0,Math.min(5000,x+event.clientX-initialX)));card.y=Math.round(Math.max(0,Math.min(5000,y+event.clientY-initialY)));article.style.left=card.x+'px';article.style.top=card.y+'px';};
      const end=()=>{head.removeEventListener('pointermove',move);head.removeEventListener('pointerup',end);head.removeEventListener('pointercancel',end);article.style.zIndex='';saveBoard();};
      head.addEventListener('pointermove',move);head.addEventListener('pointerup',end);head.addEventListener('pointercancel',end);
    });
    head.addEventListener('keydown',e=>{const delta={ArrowLeft:[-20,0],ArrowRight:[20,0],ArrowUp:[0,-20],ArrowDown:[0,20]}[e.key];if(!delta)return;e.preventDefault();card.x=Math.max(0,Math.min(5000,card.x+delta[0]));card.y=Math.max(0,Math.min(5000,card.y+delta[1]));article.style.left=card.x+'px';article.style.top=card.y+'px';saveBoard();});
    width=Math.max(width,card.x+350);height=Math.max(height,card.y+480);
  }
  $('boardCanvas').style.width=width+'px';$('boardCanvas').style.height=height+'px';
}
function openCard(card=null){stopVoice();state.editing=card?.id||null;$('cardDialogTitle').textContent=card?'Editar ideia':'Nova ideia';$('cardTitle').value=card?.title||'';$('cardText').value=card?.text||'';$('cardDialog').showModal();}
function openWhatsApp(text=''){$('waText').value=text;$('waLink').hidden=true;$('waLink').removeAttribute('href');$('waError').textContent='';if(!$('whatsappDialog').open)$('whatsappDialog').showModal();}
function voiceFields() {
  $('geminiVoiceField').hidden = $('speechEngine').value !== 'gemini';
  $('systemVoiceField').hidden = $('speechEngine').value !== 'system';
}
function providerFields() {
  const nvidia = $('provider').value === 'nvidia';
  $('geminiFields').hidden = nvidia; $('nvidiaFields').hidden = !nvidia;
}
function applyStatus(data) {
  state.online = data.online; state.speechEngine = data.speech_engine || 'gemini'; state.geminiVoice = data.voice || 'Charon';
  $('onlineToggle').checked = data.online; $('rememberKey').checked = Boolean(data.remember_key);
  state.provider = data.provider || 'gemini'; $('provider').value = state.provider; providerFields();
  if (data.nvidia_model && !Array.from($('nvidiaModel').options).some(o => o.value === data.nvidia_model)) {
    const extra = document.createElement('option'); extra.value = extra.textContent = data.nvidia_model; $('nvidiaModel').append(extra);
  }
  if (data.nvidia_model) $('nvidiaModel').value = data.nvidia_model;
  $('nvidiaKeyHint').textContent = data.has_nvidia_key ? 'Chave NVIDIA configurada. Deixe em branco para manter.'
    : 'Gere em build.nvidia.com › Settings › API Keys. A conta é gratuita e não pede cartão.';
  if (data.model && !Array.from($('modelName').options).some(o => o.value === data.model)) {
    const extra = document.createElement('option'); extra.value = extra.textContent = data.model; $('modelName').append(extra);
  }
  $('modelName').value = data.model;
  $('speechEngine').value = state.speechEngine; $('geminiVoice').value = state.geminiVoice; voiceFields();
  $('modeBadge').innerHTML = '<i></i>'; $('modeBadge').append(document.createTextNode(data.online ? ' Gemini online' : ' Modo local'));
  $('modeBadge').classList.toggle('online',data.online); $('connectionText').textContent = data.online ? (state.provider === 'nvidia' ? 'NVIDIA ativa' : 'Gemini ativo') : 'Modo local';
  $('keyHint').textContent = data.has_key ? 'Chave Google configurada nesta sessão. Deixe em branco para manter.' : 'A chave fica apenas na memória desta sessão.';
}
async function saveSettings(close=true) {
  const data = await api('settings', {online:$('onlineToggle').checked, key:$('apiKey').value.trim(),
    model:$('modelName').value, voice:$('geminiVoice').value, speech_engine:$('speechEngine').value,
    remember_key:$('rememberKey').checked, provider:$('provider').value,
    nvidia_key:$('nvidiaKey').value.trim(), nvidia_model:$('nvidiaModel').value});
  applyStatus(data); state.voice = $('voiceSelect').value; $('apiKey').value = ''; $('nvidiaKey').value = ''; $('settingsError').textContent = '';
  if (close) $('settingsDialog').close();
  return data;
}
$('chatForm').addEventListener('submit',e=>{e.preventDefault();sendMessage($('message').value);});
$('message').addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();sendMessage($('message').value);}});
$('micBtn').onclick=()=>{if(state.recording)state.recorder.stop();else startRecording();};
$('stopBtn').onclick=stopVoice;
$('autoConversation').onchange=()=>{if($('autoConversation').checked){state.continuous=true;startRecording();}else stopVoice();};
$('pauseBtn').onclick=()=>{stopVoice();stopCamera();removePhoto();setPhase('paused','Microfone e câmera desligados.');log('Sessão de voz e câmera pausada.');};
$('cameraBtn').onclick=toggleCamera;$('visionBtn').onclick=preparePhoto;$('removeImageBtn').onclick=removePhoto;
$('assistantTab').onclick=()=>showTab(false);$('boardTab').onclick=()=>showTab(true);
$('fullscreenBtn').onclick=async()=>{try{if(document.fullscreenElement)await document.exitFullscreen();else await document.documentElement.requestFullscreen();}catch{toast('Use F11 para alternar tela cheia.');}};
$('settingsBtn').onclick=()=>{stopVoice();$('settingsError').textContent='';$('settingsDialog').showModal();};
for(const button of document.querySelectorAll('[data-close]'))button.onclick=()=>$(button.dataset.close).close();
$('speechEngine').onchange = voiceFields;
$('provider').onchange = providerFields;
$('settingsForm').onsubmit = async e => {
  e.preventDefault(); if (state.busy) return; state.busy = true; controls();
  try { const data = await saveSettings(); toast('Configurações aplicadas.'); log(data.online ? 'Gemini ativado pelo usuário.' : 'Modo local ativado.'); }
  catch(error) { $('settingsError').textContent = error.message; }
  finally { state.busy = false; controls(); }
};
$('testConnectionBtn').onclick = async () => {
  if (state.busy) return; stopVoice(); state.busy = true; controls();
  try { await saveSettings(false); $('settingsError').textContent = 'Testando…'; const result = await api('test',{}); $('settingsError').textContent = result.message; log('Conexão com o Gemini testada.'); }
  catch(error) { $('settingsError').textContent = error.message; }
  finally { state.busy = false; controls(); }
};
$('detectModelsBtn').onclick = async () => {
  if (state.busy) return; stopVoice(); state.busy = true; controls();
  try {
    await saveSettings(false);
    $('settingsError').textContent = 'Consultando o Google…';
    const result = await api('models', {});
    const select = result.provider === 'nvidia' ? $('nvidiaModel') : $('modelName');
    select.replaceChildren();
    for (const name of result.models) { const option = document.createElement('option'); option.value = option.textContent = name; select.append(option); }
    select.value = result.model;
    $('settingsError').textContent = `Modelos liberados para esta chave: ${result.models.join(', ')}. Em uso: ${result.model}.`;
    log('Lista de modelos atualizada pela API.');
  } catch (error) { $('settingsError').textContent = error.message; }
  finally { state.busy = false; controls(); }
};
$('testVoiceBtn').onclick = async () => {
  if (state.busy) return; stopVoice(); state.busy = true; controls();
  try { await saveSettings(true); await speak('Olá, João. Sistemas prontos. Como posso ajudar?',state.epoch); }
  catch(error) { $('settingsError').textContent = error.message; toast(error.message); }
  finally { state.busy = false; controls(); }
};
$('forgetKeyBtn').onclick = async () => {
  if (state.busy) return; stopVoice(); state.busy = true; controls();
  try { applyStatus(await api('settings',{online:false,clear_key:true,model:$('modelName').value})); $('apiKey').value = ''; toast('Chaves removidas da sessão.'); }
  catch(error) { $('settingsError').textContent = error.message; }
  finally { state.busy = false; controls(); }
};
$('settingsDialog').addEventListener('close',()=>{$('apiKey').value='';$('nvidiaKey').value='';});
$('clearBtn').onclick=async()=>{if(state.busy)return;stopVoice();try{await api('clear',{});$('chat').replaceChildren();state.chat=[];addMessage('assistant','Conversa local limpa. Como posso ajudar?','local');}catch(error){toast(error.message);}};
$('writeBtn').onclick=()=>{showTab(false);$('message').value='Elabore um texto sobre ';$('message').focus();};
$('calcBtn').onclick=()=>{showTab(false);$('message').value='/calcular ';$('message').focus();};
$('whatsappBtn').onclick=()=>{stopVoice();openWhatsApp();};
$('whatsappForm').onsubmit=async e=>{e.preventDefault();$('waLink').hidden=true;try{const data=await api('whatsapp',{phone:$('phone').value,text:$('waText').value});$('waLink').href=data.url;$('waLink').hidden=false;$('waError').textContent='';log('Link de rascunho preparado. Nenhuma mensagem enviada.');}catch(error){$('waError').textContent=error.message;}};
for(const field of ['phone','waText'])$(field).oninput=()=>{$('waLink').hidden=true;$('waLink').removeAttribute('href');};
$('waLink').onclick=()=>{log('Abertura do WhatsApp solicitada.');};
$('noteBtn').onclick=()=>openCard();$('newCardBtn').onclick=()=>openCard();
$('cardForm').onsubmit=e=>{e.preventDefault();if(state.editing){const card=state.cards.find(c=>c.id===state.editing);if(card){card.title=$('cardTitle').value;card.text=$('cardText').value;renderBoard();saveBoard();}}else addCard({title:$('cardTitle').value,text:$('cardText').value});$('cardDialog').close();};
$('addImageBtn').onclick=()=>$('imageFile').click();
$('imageFile').onchange=async()=>{const file=$('imageFile').files[0];$('imageFile').value='';if(!file)return;if(file.size>12000000)return toast('Escolha uma imagem de até 12 MB.');try{const bitmap=await createImageBitmap(file),canvas=document.createElement('canvas');const ratio=Math.min(1,1000/Math.max(bitmap.width,bitmap.height));canvas.width=Math.round(bitmap.width*ratio);canvas.height=Math.round(bitmap.height*ratio);canvas.getContext('2d').drawImage(bitmap,0,0,canvas.width,canvas.height);bitmap.close();addCard({title:file.name.slice(0,100),text:'',image:canvas.toDataURL('image/jpeg',.75)});}catch{toast('Não foi possível abrir a imagem. Use JPG, PNG ou WebP.');}};
$('exportBoardBtn').onclick=()=>download('quadro_jarvis.json',JSON.stringify(state.cards,null,2),'application/json');
window.addEventListener('pagehide',()=>{stopVoice();stopCamera();});
document.addEventListener('visibilitychange',()=>{if(document.hidden)stopVoice();});
if('speechSynthesis'in window){speechSynthesis.onvoiceschanged=voices;voices();}
setInterval(()=>{$('clock').textContent=new Date().toLocaleTimeString('pt-BR',{hour:'2-digit',minute:'2-digit'});},1000);
(async()=>{try{applyStatus(await api('status'));log('Interface pronta.');try{const saved=await api('board');state.cards=saved.cards;state.boardReady=true;renderBoard();}catch(error){$('saveStatus').textContent='Quadro indisponível';toast(error.message);}addMessage('assistant','Olá, João. Posso ajudar com cálculos, textos e mensagens.\n\nExperimente “quanto é 25 vezes 4”. Use /lembrar para eu guardar algo sobre você e /memoria para ver o que já está salvo. Para conversar por voz ou analisar uma foto, ative a IA em Configurações.','local');}catch(error){addMessage('error',error.message);$('connectionText').textContent='Sem conexão local';}controls();})();
