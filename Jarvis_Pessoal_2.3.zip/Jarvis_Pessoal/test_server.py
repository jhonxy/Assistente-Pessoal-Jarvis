import base64
import json
import io
import wave
import tempfile
import threading
import unittest
import urllib.error
import urllib.request
from unittest.mock import patch

from app import Handler, Server, State, validate_board
from core import ask_ai, local_reply, transcribe, validate_image, synthesize


class IntegrationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory()
        cls.server = Server(('127.0.0.1', 0), Handler)
        cls.server.state = State(cls.tmp.name)
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()
        cls.base = f'http://127.0.0.1:{cls.server.server_port}'

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()
        cls.tmp.cleanup()

    def setUp(self):
        self.server.state.key = ''
        self.server.state.online = False
        self.server.state.history.clear()

    def call(self, path, body=None, token=True, origin=None):
        headers = {'Content-Type': 'application/json'}
        if token:
            headers['X-Jarvis-Token'] = self.server.state.token
        if origin:
            headers['Origin'] = origin
        req = urllib.request.Request(self.base + '/api/' + path,
            data=None if body is None else json.dumps(body).encode(), headers=headers)
        try:
            with urllib.request.urlopen(req) as res:
                return res.status, json.load(res)
        except urllib.error.HTTPError as exc:
            return exc.code, json.load(exc)

    def test_access_boundaries(self):
        self.assertEqual(self.call('status', token=False)[0], 403)
        self.assertEqual(self.call('chat', {'text':'oi'}, origin='https://example.com')[0], 403)
        req = urllib.request.Request(self.base + '/', headers={'Host':'evil.example'})
        with self.assertRaises(urllib.error.HTTPError) as error:
            urllib.request.urlopen(req)
        self.assertEqual(error.exception.code, 403)

    @patch('core.urllib.request.urlopen')
    def test_local_router_no_external_request(self, outgoing):
        self.assertEqual(local_reply('Jarvis, quanto é 25 vezes 4?')['answer'], 'Resultado: 100')
        self.assertEqual(local_reply('Calcule 15 por cento de 200')['answer'], 'Resultado: 30')
        self.assertEqual(local_reply('/whatsapp')['action'], 'whatsapp')
        outgoing.assert_not_called()

    def test_local_chat_and_missing_key(self):
        code, data = self.call('chat', {'text':'/calcular 15% de 200'})
        self.assertEqual((code, data['answer']), (200, 'Resultado: 30'))
        code, data = self.call('chat', {'text':'Escreva um e-mail'})
        self.assertEqual(data['source'], 'local')
        self.assertEqual(self.call('settings', {'online':True,'key':''})[0], 400)

    def test_board_roundtrip_and_validation(self):
        cards = [{'id':'one','title':'Ideia','text':'Olá <script>','x':30,'y':40}]
        self.assertEqual(self.call('board', {'cards':cards})[0], 200)
        self.assertEqual(self.call('board')[1]['cards'], cards)
        self.assertEqual(State(self.tmp.name).board(), cards)
        self.assertEqual(self.call('board', {'cards':cards*2})[0], 400)
        self.assertEqual(self.call('board', {'cards':[dict(cards[0], x=float('nan'))]})[0], 400)
        self.assertEqual(self.call('board', {'cards':[dict(cards[0], image='javascript:bad') ]})[0], 400)

    def test_key_not_exposed_and_busy_guard(self):
        self.assertEqual(self.call('settings', {'online':True,'key':'test-not-real','model':'gemini-3.5-flash-lite'})[0], 200)
        status = self.call('status')[1]
        self.assertTrue(status['has_key'])
        self.assertNotIn('test-not-real', json.dumps(status))
        self.server.state.operation.acquire()
        try:
            self.assertEqual(self.call('chat', {'text':'oi'})[0], 409)
        finally:
            self.server.state.operation.release()
        self.assertEqual(self.call('settings', {'online':False,'clear_key':True})[0], 200)
        self.assertFalse(self.call('status')[1]['has_key'])

    @patch('app.ask_ai_resilient')
    def test_online_history_photo_not_retained(self, ai):
        ai.return_value = ('Vejo uma foto.', 'gemini-3.5-flash-lite')
        self.call('settings', {'online':True,'key':'test-not-real'})
        image = 'data:image/jpeg;base64,' + base64.b64encode(b'\xff\xd8\xffmock').decode()
        code, response = self.call('chat', {'text':'Descreva','image':image})
        self.assertEqual(code, 200)
        self.assertEqual(ai.call_args.args[4], image)
        self.assertNotIn(image, json.dumps(self.server.state.history))
        self.assertEqual(len(self.server.state.history), 2)
        self.call('clear', {})
        self.assertEqual(self.server.state.history, [])

    def test_whatsapp_draft_only(self):
        code, data = self.call('whatsapp', {'phone':'+55 (31) 99999-9999','text':'Olá & você?'})
        self.assertEqual(code, 200)
        self.assertTrue(data['url'].startswith('https://wa.me/5531999999999?text='))
        self.assertIn('%26', data['url'])
        self.assertEqual(self.call('whatsapp', {'phone':'Maria','text':'oi'})[0], 400)


    @patch('app.synthesize')
    def test_speech_endpoint_requires_key_and_uses_selected_voice(self, tts):
        self.assertEqual(self.call('speak', {'text':'Olá'})[0], 400)
        tts.assert_not_called()
        self.call('settings', {'online':True,'key':'test-only','voice':'Orus','speech_engine':'gemini'})
        tts.return_value = b'RIFF-test'
        code, data = self.call('speak', {'text':'Olá'})
        self.assertEqual(code, 200)
        self.assertEqual(base64.b64decode(data['audio']), b'RIFF-test')
        tts.assert_called_once_with('test-only', 'Olá', 'Orus')
        self.assertEqual(self.call('settings', {'online':True,'model':'gpt-4.1-mini'})[0], 400)
        self.assertEqual(self.call('settings', {'online':True,'voice':'unknown'})[0], 400)

    def test_memory_survives_restart_and_reaches_the_model(self):
        self.assertEqual(self.call('chat', {'text':'/esquecer tudo'})[1]['answer'][:16], 'Memória apagada.')
        self.assertIn('Guardado', self.call('chat', {'text':'/lembrar curso de Engenharia de Software'})[1]['answer'])
        self.assertIn('Engenharia', self.call('chat', {'text':'/memoria'})[1]['answer'])
        self.assertEqual(State(self.tmp.name).facts, ['curso de Engenharia de Software'])
        with patch('app.ask_ai_resilient') as ai:
            ai.return_value = ('Certo.', 'gemini-3.5-flash-lite')
            self.call('settings', {'online':True,'key':'test-not-real'})
            self.call('chat', {'text':'O que eu curso?'})
            self.assertEqual(ai.call_args.args[5], ['curso de Engenharia de Software'])
        self.assertIn('Removido', self.call('chat', {'text':'/esquecer 1'})[1]['answer'])
        self.assertEqual(self.call('chat', {'text':'/esquecer 9'})[0], 400)

    def test_preferences_persist_but_key_only_when_asked(self):
        self.call('settings', {'online':True,'key':'segredo-teste','model':'gemini-3.6-flash','voice':'Orus'})
        reloaded = State(self.tmp.name)
        self.assertEqual((reloaded.model, reloaded.voice), ('gemini-3.6-flash', 'Orus'))
        self.assertFalse(reloaded.key)
        self.call('settings', {'online':True,'key':'segredo-teste','model':'gemini-3.6-flash','remember_key':True})
        self.assertTrue(State(self.tmp.name).key)
        self.call('settings', {'online':False,'clear_key':True,'model':'gemini-3.6-flash'})
        self.assertFalse(State(self.tmp.name).key)

    @patch('app.ask_nvidia')
    def test_nvidia_provider_routes_chat_and_blocks_photo(self, nvidia):
        nvidia.return_value = 'Resposta da NVIDIA.'
        code, data = self.call('settings', {'online': True, 'provider': 'nvidia',
                                            'nvidia_key': 'nvapi-teste', 'nvidia_model': 'meta/llama-3.3-70b-instruct'})
        self.assertEqual((code, data['provider'], data['has_nvidia_key']), (200, 'nvidia', True))
        self.assertNotIn('nvapi-teste', json.dumps(data))
        self.assertEqual(self.call('chat', {'text': 'Explique POO'})[1]['answer'], 'Resposta da NVIDIA.')
        self.assertEqual(nvidia.call_args.args[1], 'meta/llama-3.3-70b-instruct')
        image = 'data:image/jpeg;base64,' + base64.b64encode(b'\xff\xd8\xffmock').decode()
        self.assertEqual(self.call('chat', {'text': 'Descreva', 'image': image})[0], 400)
        self.assertEqual(self.call('speak', {'text': 'Olá'})[0], 400)
        self.assertEqual(self.call('settings', {'online': True, 'provider': 'openai'})[0], 400)
        self.call('settings', {'online': False, 'clear_key': True, 'provider': 'gemini'})

    def test_session_code_survives_a_restart(self):
        reopened = State(self.tmp.name)
        self.assertEqual(reopened.token, self.server.state.token)
        self.assertGreaterEqual(len(reopened.token), 32)
        self.assertEqual(self.call('status', token=False)[0], 403)

    @patch('app.list_models')
    def test_model_detection_switches_away_from_retired_model(self, models):
        self.assertEqual(self.call('models', {})[0], 400)
        self.call('settings', {'online':True,'key':'test-not-real','model':'gemini-2.5-flash'})
        models.return_value = ['gemini-3.5-flash-lite', 'gemini-3.6-flash']
        code, data = self.call('models', {})
        self.assertEqual((code, data['model']), (200, 'gemini-3.5-flash-lite'))
        self.assertEqual(self.call('status')[1]['model'], 'gemini-3.5-flash-lite')


class MediaTests(unittest.TestCase):
    @patch('core.request_api')
    def test_transcription_inline_audio(self, api):
        api.return_value = {'candidates':[{'content':{'parts':[{'text':'Quanto é dois mais dois?'}]}}]}
        audio = b'audio' * 30
        self.assertEqual(transcribe('test', audio, 'audio/webm;codecs=opus'), 'Quanto é dois mais dois?')
        self.assertEqual(api.call_args.args[1], 'gemini-3.5-flash-lite')
        payload = api.call_args.args[2]
        block = payload['contents'][0]['parts'][1]['inlineData']
        self.assertEqual(block['mimeType'], 'audio/webm')
        self.assertEqual(base64.b64decode(block['data']), audio)
        with self.assertRaises(ValueError):
            transcribe('test', b'too short', 'text/plain')
        api.return_value = {'candidates':[]}
        with self.assertRaises(ValueError):
            transcribe('test', audio, 'audio/webm')
        api.return_value = {'candidates':[{'content':{'parts':[{'text':'[SEM_FALA]'}]}}]}
        with self.assertRaises(ValueError):
            transcribe('test', audio, 'audio/webm')

    @patch('core.request_api')
    def test_vision_request_and_history_bound(self, api):
        api.return_value={'candidates':[{'content':{'parts':[{'text':'Foto.'}]}}]}
        raw = b'\x89PNG\r\n\x1a\nmock'
        image='data:image/png;base64,'+base64.b64encode(raw).decode()
        history=[{'role':'user','content':'Oi'}]*20
        self.assertEqual(ask_ai('test','gemini-3.5-flash-lite',history,'O que é?',image),'Foto.')
        body=api.call_args.args[2]
        self.assertEqual(len(body['contents']),13)
        self.assertEqual(base64.b64decode(body['contents'][-1]['parts'][1]['inlineData']['data']),raw)
        with self.assertRaises(ValueError):
            validate_image('https://example.com/a.jpg')

    @patch('core.request_api')
    def test_synthetic_voice_wav_and_limits(self, api):
        pcm=b'\x00\x00'*2400
        api.return_value={'candidates':[{'content':{'parts':[{'inlineData':{
            'mimeType':'audio/L16;codec=pcm;rate=24000','data':base64.b64encode(pcm).decode()}}]}}]}
        result=synthesize('test','Olá, João.','Charon')
        with wave.open(io.BytesIO(result),'rb') as wav:
            self.assertEqual(wav.getframerate(),24000)
            self.assertEqual(wav.getnchannels(),1)
            self.assertEqual(wav.getsampwidth(),2)
            self.assertEqual(wav.readframes(2400),pcm)
        self.assertEqual(api.call_args.args[1],'gemini-3.1-flash-tts-preview')
        config=api.call_args.args[2]['generationConfig']
        self.assertEqual(config['speechConfig']['voiceConfig']['prebuiltVoiceConfig']['voiceName'],'Charon')
        calls=api.call_count
        for text,voice in [('x'*1501,'Charon'),('Oi','invalid')]:
            with self.assertRaises(ValueError):
                synthesize('test',text,voice)
        self.assertEqual(api.call_count,calls)

    @patch('core.request_api')
    def test_reject_bad_audio_and_thoughts_not_exposed(self, api):
        api.return_value={'candidates':[{'content':{'parts':[{'text':'interno','thought':True},{'text':'Resposta'}]}}]}
        self.assertEqual(ask_ai('test','gemini-3.5-flash-lite',[],'Oi'),'Resposta')
        for data in [{'candidates':[]},{'candidates':[{'content':{'parts':[{'inlineData':{'mimeType':'audio/L16','data':'!bad'}}]}}]}]:
            api.return_value=data
            with self.assertRaises(ValueError):
                synthesize('test','Oi')


if __name__ == '__main__':
    unittest.main()
