"""JARVIS 2.3: servidor local + janela Edge/Chrome. Python padrão, sem pip."""
import argparse
import base64
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import os
from pathlib import Path
import re
import secrets
import subprocess
import threading
import urllib.parse
import webbrowser

from core import (ask_ai_resilient, ask_nvidia, local_reply, memory_command, list_models,
                  list_nvidia_models, transcribe, synthesize, validate_image, whatsapp_url,
                  DEFAULT_MODEL, CHAT_MODELS, VOICES, NVIDIA_DEFAULT, PROVIDERS)

ROOT = Path(__file__).resolve().parent
WEB = ROOT / 'web'


MAX_FACTS = 200


class State:
    def __init__(self, directory=None):
        self.token = secrets.token_urlsafe(32)
        self.key = os.environ.get('GEMINI_API_KEY', '')
        self.model = DEFAULT_MODEL
        self.voice = 'Charon'
        self.speech_engine = 'gemini'
        self.online = False
        self.remember_key = False
        self.provider = 'gemini'
        self.nvidia_key = os.environ.get('NVIDIA_API_KEY', '')
        self.nvidia_model = NVIDIA_DEFAULT
        self.history = []
        self.facts = []
        self.operation = threading.Lock()
        self.storage = threading.Lock()
        folder = Path(directory) if directory else ROOT / 'dados'
        self.board_file = folder / 'quadro.json'
        self.memory_file = folder / 'memoria.json'
        self.config_file = folder / 'config.json'
        self.load_memory()
        self.load_config()
        self.save_config()  # grava o código de sessão já no primeiro uso

    def status(self):
        return {'online': self.online, 'has_key': bool(self.key), 'model': self.model,
                'voice': self.voice, 'speech_engine': self.speech_engine, 'version': '2.3',
                'provider': self.provider, 'remember_key': self.remember_key,
                'models': list(CHAT_MODELS), 'facts': len(self.facts),
                'has_nvidia_key': bool(self.nvidia_key), 'nvidia_model': self.nvidia_model}

    def chat_key(self):
        return self.nvidia_key if self.provider == 'nvidia' else self.key

    # ----- memória de longo prazo -----
    def load_memory(self):
        try:
            data = json.loads(self.memory_file.read_text('utf-8'))
        except (OSError, ValueError):
            return
        facts = data.get('fatos') if isinstance(data, dict) else None
        self.facts = [str(f)[:400] for f in facts][:MAX_FACTS] if isinstance(facts, list) else []

    def save_memory(self):
        with self.storage:
            self.memory_file.parent.mkdir(exist_ok=True, parents=True)
            temp = self.memory_file.with_suffix('.tmp')
            temp.write_text(json.dumps({'fatos': self.facts}, ensure_ascii=False, indent=1), 'utf-8')
            temp.replace(self.memory_file)

    def remember(self, fact):
        if fact in self.facts:
            return 'Isso já está na memória.'
        if len(self.facts) >= MAX_FACTS:
            raise ValueError(f'A memória chegou ao limite de {MAX_FACTS} itens. Use /esquecer para abrir espaço.')
        self.facts.append(fact)
        self.save_memory()
        return f'Guardado. Agora são {len(self.facts)} item(ns) na memória.'

    def forget(self, target):
        if target == 'all':
            self.facts.clear()
            self.save_memory()
            return 'Memória apagada. Nenhum fato guardado.'
        if not 1 <= target <= len(self.facts):
            raise ValueError('Não existe um item com esse número. Veja a lista com /memoria.')
        removed = self.facts.pop(target - 1)
        self.save_memory()
        return f'Removido: {removed}'

    def list_facts(self):
        if not self.facts:
            return ('Ainda não guardei nada. Use /lembrar seguido do que você quer que eu saiba, '
                    'por exemplo: /lembrar curso Engenharia de Software e uso C# na faculdade.')
        lines = '\n'.join(f'{index}. {fact}' for index, fact in enumerate(self.facts, 1))
        return f'O que está guardado neste PC ({len(self.facts)} item(ns)):\n{lines}\n\nUse /esquecer com o número para remover.'

    # ----- preferências -----
    def load_config(self):
        try:
            data = json.loads(self.config_file.read_text('utf-8'))
        except (OSError, ValueError):
            return
        if not isinstance(data, dict):
            return
        sessao = data.get('sessao')
        if isinstance(sessao, str) and len(sessao) >= 32:
            self.token = sessao  # mantém a janela aberta válida depois de reiniciar
        if data.get('model') in CHAT_MODELS:
            self.model = data['model']
        if data.get('provider') in PROVIDERS:
            self.provider = data['provider']
        nvidia_model = data.get('nvidia_model')
        if isinstance(nvidia_model, str) and 1 <= len(nvidia_model) <= 120:
            self.nvidia_model = nvidia_model
        if data.get('voice') in VOICES:
            self.voice = data['voice']
        if data.get('speech_engine') in ('gemini', 'system'):
            self.speech_engine = data['speech_engine']
        nvidia_key = data.get('nvidia_key')
        if isinstance(nvidia_key, str) and nvidia_key.strip() and not self.nvidia_key:
            self.nvidia_key, self.remember_key = nvidia_key.strip(), True
        key = data.get('key')
        if isinstance(key, str) and key.strip() and not self.key:
            self.key, self.remember_key = key.strip(), True
        if (self.key or self.nvidia_key) and data.get('online') is True:
            self.online = True

    def save_config(self):
        payload = {'sessao': self.token, 'model': self.model, 'voice': self.voice,
                   'speech_engine': self.speech_engine, 'online': self.online,
                   'provider': self.provider, 'nvidia_model': self.nvidia_model}
        if self.remember_key and self.key:
            payload['key'] = self.key
        if self.remember_key and self.nvidia_key:
            payload['nvidia_key'] = self.nvidia_key
        with self.storage:
            self.config_file.parent.mkdir(exist_ok=True, parents=True)
            temp = self.config_file.with_suffix('.tmp')
            temp.write_text(json.dumps(payload, ensure_ascii=False, indent=1), 'utf-8')
            temp.replace(self.config_file)
            try:
                os.chmod(self.config_file, 0o600)
            except OSError:
                pass

    def board(self):
        with self.storage:
            if not self.board_file.exists():
                return []
            try:
                return validate_board(json.loads(self.board_file.read_text('utf-8')))
            except (ValueError, OSError):
                raise ValueError('Não foi possível ler o quadro salvo. Preserve dados/quadro.json para recuperação.')

    def save_board(self, cards):
        cards = validate_board(cards)
        with self.storage:
            self.board_file.parent.mkdir(exist_ok=True, parents=True)
            temp = self.board_file.with_suffix('.tmp')
            temp.write_text(json.dumps(cards, ensure_ascii=False), 'utf-8')
            temp.replace(self.board_file)


def validate_board(cards):
    if not isinstance(cards, list) or len(cards) > 30:
        raise ValueError('Use até 30 cartões no quadro.')
    result, seen = [], set()
    for card in cards:
        if not isinstance(card, dict):
            raise ValueError('Cartão inválido.')
        identity = card.get('id', '')
        title, body = card.get('title', ''), card.get('text', '')
        if (not isinstance(identity, str) or not re.fullmatch(r'[a-zA-Z0-9_-]{1,60}', identity)
                or identity in seen or not isinstance(title, str) or len(title) > 100
                or not isinstance(body, str) or len(body) > 16000):
            raise ValueError('Conteúdo do cartão inválido ou muito grande.')
        seen.add(identity)
        item = {'id': identity, 'title': title, 'text': body}
        for axis in ('x', 'y'):
            value = card.get(axis, 20)
            if type(value) not in (int, float) or not 0 <= value <= 5000:
                raise ValueError('Posição do cartão inválida.')
            item[axis] = value
        if card.get('image'):
            item['image'] = validate_image(card['image'])
        result.append(item)
    if len(json.dumps(result).encode()) > 4000000:
        raise ValueError('Quadro cheio. Remova algumas imagens antes de salvar.')
    return result


class Server(ThreadingHTTPServer):
    daemon_threads = True


class Handler(BaseHTTPRequestHandler):
    server_version = 'Jarvis/2.3'

    def log_message(self, *args):
        pass  # Não registra chaves, áudio, texto ou URLs de sessão.

    def valid_host(self):
        return self.headers.get('Host') == f'127.0.0.1:{self.server.server_port}'

    def authorized(self):
        origin = self.headers.get('Origin')
        expected = f'http://127.0.0.1:{self.server.server_port}'
        return (self.valid_host() and (not origin or origin == expected) and
                secrets.compare_digest(self.headers.get('X-Jarvis-Token', ''), self.server.state.token))

    def reply(self, status, data, content_type='application/json; charset=utf-8'):
        if not isinstance(data, bytes):
            data = json.dumps(data, ensure_ascii=False).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', content_type)
        self.send_header('Content-Length', str(len(data)))
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('Referrer-Policy', 'no-referrer')
        self.send_header('X-Frame-Options', 'DENY')
        self.send_header('Content-Security-Policy', "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; media-src 'self' blob:; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'none'")
        self.end_headers()
        try:
            self.wfile.write(data)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def do_GET(self):
        if not self.valid_host():
            return self.reply(403, {'error': 'Host inválido.'})
        path = urllib.parse.urlsplit(self.path).path
        assets = {'/': ('index.html', 'text/html'), '/app.js': ('app.js', 'text/javascript'),
                  '/style.css': ('style.css', 'text/css')}
        if path in assets:
            file, content_type = assets[path]
            return self.reply(200, (WEB / file).read_bytes(), content_type + '; charset=utf-8')
        if not self.authorized():
            return self.reply(403, {'error': 'Sessão inválida. Abra o aplicativo pelo Iniciar.bat.'})
        try:
            if path == '/api/status':
                return self.reply(200, self.server.state.status())
            if path == '/api/board':
                return self.reply(200, {'cards': self.server.state.board()})
            self.reply(404, {'error': 'Página não encontrada.'})
        except ValueError as exc:
            self.reply(400, {'error': str(exc)})

    def do_POST(self):
        if not self.authorized():
            return self.reply(403, {'error': 'Sessão inválida. Reabra o aplicativo pelo Iniciar.bat.'})
        path = urllib.parse.urlsplit(self.path).path
        state, locked = self.server.state, False
        try:
            length = int(self.headers.get('Content-Length', '0'))
            if not 0 < length <= (8000000 if path == '/api/transcribe' else 4500000):
                return self.reply(413, {'error': 'Conteúdo vazio ou grande demais.'})
            raw = self.rfile.read(length)
            if path == '/api/transcribe':
                locked = state.operation.acquire(timeout=0.75)
                if not locked:
                    return self.reply(409, {'error': 'Aguarde a tarefa atual terminar.'})
                if not state.online or not state.key:
                    raise ValueError('A transcrição de voz usa o Gemini. Informe a chave do Google em Configurações; '
                                     'a NVIDIA não cobre esse recurso nesta versão.')
                return self.reply(200, {'text': transcribe(state.key, raw, self.headers.get('Content-Type', ''), state.model)})
            if self.headers.get('Content-Type', '').split(';')[0] != 'application/json':
                return self.reply(415, {'error': 'Envie dados JSON.'})
            data = json.loads(raw)
            if not isinstance(data, dict):
                raise ValueError('Dados inválidos.')
            if path == '/api/board':
                state.save_board(data.get('cards'))
                return self.reply(200, {'ok': True})
            if path == '/api/whatsapp':
                return self.reply(200, {'url': whatsapp_url(str(data.get('phone', '')), str(data.get('text', '')))})
            locked = state.operation.acquire(timeout=0.75)
            if not locked:
                return self.reply(409, {'error': 'Aguarde a tarefa atual terminar.'})
            if path == '/api/settings':
                key, model = data.get('key', ''), data.get('model', DEFAULT_MODEL)
                if not isinstance(key, str) or len(key) > 512 or any(ord(c) < 32 or ord(c) > 126 for c in key):
                    raise ValueError('Chave inválida.')
                if model not in CHAT_MODELS:
                    raise ValueError('Selecione um modelo Gemini disponível na lista.')
                voice = data.get('voice', state.voice)
                engine = data.get('speech_engine', state.speech_engine)
                if voice not in VOICES or engine not in ('gemini', 'system'):
                    raise ValueError('Configuração de voz inválida.')
                nvidia_key = data.get('nvidia_key', '')
                if not isinstance(nvidia_key, str) or len(nvidia_key) > 512 or any(ord(c) < 32 or ord(c) > 126 for c in nvidia_key):
                    raise ValueError('Chave NVIDIA inválida.')
                provider = data.get('provider', state.provider)
                if provider not in PROVIDERS:
                    raise ValueError('Selecione Google Gemini ou NVIDIA.')
                nvidia_model = str(data.get('nvidia_model') or state.nvidia_model).strip()
                if not 1 <= len(nvidia_model) <= 120:
                    raise ValueError('Informe o nome do modelo da NVIDIA.')
                new_key = '' if data.get('clear_key') else key.strip() or state.key
                new_nvidia = '' if data.get('clear_key') else nvidia_key.strip() or state.nvidia_key
                online = data.get('online') is True
                chosen = new_nvidia if provider == 'nvidia' else new_key
                if online and not chosen:
                    raise ValueError('Informe a chave do provedor selecionado para ativar a IA online.')
                state.online, state.model, state.key = online, model, new_key
                state.provider, state.nvidia_key, state.nvidia_model = provider, new_nvidia, nvidia_model
                state.voice, state.speech_engine = voice, engine
                if 'remember_key' in data:
                    state.remember_key = data.get('remember_key') is True
                if data.get('clear_key'):
                    state.remember_key = False
                state.save_config()
                return self.reply(200, state.status())
            if path == '/api/models':
                if state.provider == 'nvidia':
                    if not state.nvidia_key:
                        raise ValueError('Informe a chave NVIDIA antes de detectar os modelos.')
                    found = list_nvidia_models(state.nvidia_key)
                    if state.nvidia_model not in found:
                        state.nvidia_model = found[0]
                        state.save_config()
                    return self.reply(200, {'models': found, 'model': state.nvidia_model,
                                            'provider': 'nvidia'})
                if not state.key:
                    raise ValueError('Informe a chave Google antes de detectar os modelos.')
                available = list_models(state.key)
                if not available:
                    raise ValueError('Esta chave não tem nenhum dos modelos conhecidos. '
                                     'Confira o projeto no AI Studio.')
                if state.model not in available:
                    state.model = available[0]
                    state.save_config()
                return self.reply(200, {'models': available, 'model': state.model, 'provider': 'gemini'})
            if path == '/api/speak':
                if not state.online or not state.key:
                    raise ValueError('A voz de IA usa o Gemini. Informe a chave do Google ou escolha Voz do sistema.')
                wav = synthesize(state.key, data.get('text', ''), state.voice)
                return self.reply(200, {'audio': base64.b64encode(wav).decode('ascii'), 'mime': 'audio/wav'})
            if path == '/api/test':
                if not state.online or not state.chat_key():
                    raise ValueError('Aplique a chave do provedor selecionado com a IA online ativada antes de testar.')
                if state.provider == 'nvidia':
                    ask_nvidia(state.nvidia_key, state.nvidia_model, [], 'Responda apenas: Conexão funcionando.')
                    return self.reply(200, {'ok': True, 'model': state.nvidia_model,
                                            'message': f'Conexão com a NVIDIA funcionando usando {state.nvidia_model}.'})
                _, used = ask_ai_resilient(state.key, state.model, [], 'Responda apenas: Conexão funcionando.')
                message = 'Conexão com o Gemini funcionando.'
                if used != state.model:
                    state.model = used
                    state.save_config()
                    message += f' O modelo anterior não existe mais para esta chave; troquei para {used}.'
                return self.reply(200, {'ok': True, 'message': message, 'model': state.model})
            if path == '/api/clear':
                state.history.clear()
                return self.reply(200, {'ok': True})
            if path == '/api/chat':
                text = data.get('text', '')
                if not isinstance(text, str) or not 1 <= len(text.strip()) <= 12000:
                    raise ValueError('Digite uma mensagem de até 12.000 caracteres.')
                text, photo = text.strip(), data.get('image')
                if not photo:
                    command = memory_command(text)
                    if command:
                        action, value = command
                        if action == 'add':
                            return self.reply(200, {'answer': state.remember(value), 'source': 'local'})
                        if action == 'list':
                            return self.reply(200, {'answer': state.list_facts(), 'source': 'local'})
                        return self.reply(200, {'answer': state.forget(value), 'source': 'local'})
                reply = None if photo else local_reply(text)
                if reply:
                    return self.reply(200, reply)
                if not state.online or not state.chat_key():
                    return self.reply(200, {'answer': 'Ative a IA em Configurações para conversar, criar textos e analisar fotos. '
                        'Você já pode calcular, guardar fatos com /lembrar, organizar cartões e preparar mensagens. '
                        'Digite /ajuda para começar.', 'source': 'local'})
                if state.provider == 'nvidia':
                    if photo:
                        raise ValueError('A análise de foto usa o Gemini. Troque o provedor para Google Gemini nas configurações.')
                    used = state.nvidia_model
                    answer = ask_nvidia(state.nvidia_key, used, list(state.history), text, state.facts)
                else:
                    answer, used = ask_ai_resilient(state.key, state.model, list(state.history), text, photo, state.facts)
                    if used != state.model:
                        state.model = used
                        state.save_config()
                saved = text + (' [Uma foto foi enviada nesta pergunta; ela não está mais disponível.]' if photo else '')
                state.history.extend([{'role': 'user', 'content': saved}, {'role': 'assistant', 'content': answer}])
                state.history = state.history[-12:]
                return self.reply(200, {'answer': answer, 'source': 'online', 'model': used})
            self.reply(404, {'error': 'Ação não encontrada.'})
        except (ValueError, TypeError) as exc:
            self.reply(400, {'error': str(exc)})
        except OSError:
            self.reply(500, {'error': 'Falha no arquivo local ou na conexão. Confira as permissões e tente novamente.'})
        except Exception:
            self.reply(500, {'error': 'Não foi possível concluir a tarefa. Tente novamente.'})
        finally:
            if locked:
                state.operation.release()


def open_window(url):
    if os.name == 'nt':
        candidates = []
        for root in ('PROGRAMFILES(X86)', 'PROGRAMFILES', 'LOCALAPPDATA'):
            base = os.environ.get(root)
            if base:
                candidates += [Path(base) / 'Microsoft/Edge/Application/msedge.exe',
                               Path(base) / 'Google/Chrome/Application/chrome.exe']
        for browser in candidates:
            if browser.exists():
                subprocess.Popen([str(browser), '--app=' + url, '--window-size=1360,900'])
                return
    webbrowser.open(url)


def main():
    parser = argparse.ArgumentParser(description='JARVIS 2.3 — assistente pessoal local')
    parser.add_argument('--no-browser', action='store_true')
    parser.add_argument('--port', type=int, default=8765)
    args = parser.parse_args()
    try:
        server = Server(('127.0.0.1', args.port), Handler)
    except OSError:
        server = Server(('127.0.0.1', 0), Handler)
    server.state = State()
    url = f'http://127.0.0.1:{server.server_port}/#token={server.state.token}'
    print('JARVIS 2.3 pronto. Deixe esta janela aberta enquanto usa o assistente.')
    print('Se a interface não abrir, copie este endereço no Edge ou Chrome:')
    print(url, flush=True)
    if not args.no_browser:
        threading.Timer(0.5, open_window, args=(url,)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == '__main__':
    main()
