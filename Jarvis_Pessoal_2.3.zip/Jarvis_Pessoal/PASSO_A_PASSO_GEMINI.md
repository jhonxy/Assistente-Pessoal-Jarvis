# Passo a passo — API gratuita e voz do Jarvis

## 1. Criar a chave gratuita

1. Abra [Google AI Studio — API Keys](https://aistudio.google.com/app/apikey).
2. Entre com sua conta Google e aceite os termos.
3. Confirme que o projeto está marcado como **Free Tier**.
4. Copie a chave automática ou clique em **Create API key**.
5. Para continuar no gratuito, não selecione **Set up billing**.

As chaves criadas hoje começam com `AQ.` no lugar de `AIza`. Isso é normal e funciona no Jarvis. Nunca mostre a chave inteira em prints, vídeos ou mensagens; se isso acontecer, exclua a chave no AI Studio e crie outra.

O Google limita a quantidade de pedidos por minuto e por dia. Os limites podem mudar. Quando a cota acabar, espere a renovação; o Jarvis não ativa cobrança nem tenta outro serviço pago.

## 2. Abrir o Jarvis

1. Extraia o ZIP inteiro.
2. Instale Python 3 e marque **Add Python to PATH**.
3. Dê dois cliques em `Iniciar.bat`.
4. Deixe o terminal aberto.

## 3. Conectar a API

1. Clique na engrenagem no alto da interface.
2. Marque **Ativar Gemini online**.
3. Cole a chave em **Chave da API do Google**.
4. Escolha **Gemini 3.5 Flash-Lite · leve**.
5. Clique em **Aplicar**.
6. Abra novamente a engrenagem e clique em **Testar conexão**.

Se aparecer **Conexão com o Gemini funcionando**, a integração está pronta.

Se aparecer **modelo indisponível**, clique em **Detectar modelos**. O Jarvis consulta o Google, mostra o que a sua chave aceita hoje e seleciona um modelo ativo. Isso acontece porque o Google aposentou a família Gemini 2.5 para chaves novas, e vai se repetir a cada geração de modelos.

Se quiser que o Jarvis abra já conectado, marque **Salvar a chave neste computador** antes de aplicar. A chave passa a ficar em `dados/config.json`, em texto simples — use só no seu notebook.

## 4. Ativar a voz tecnológica

1. Em **Modo de voz**, escolha **Voz Gemini · estilo assistente**.
2. Em **Voz Gemini**, escolha **Charon · informativa**.
3. Clique em **Aplicar**.
4. Clique em **Ouvir teste**.
5. Na tela principal, mantenha **Ler respostas** marcado.

A voz é sintética, calma e tecnológica. Ela não copia a voz do ator, do dublador nem a voz original do filme.

## 5. Fazer o primeiro teste

Digite:

```text
Jarvis, apresente-se em duas frases e diga como pode me ajudar nos estudos.
```

Depois experimente o microfone:

1. Clique em **Falar**.
2. Permita o acesso ao microfone.
3. Diga: `Elabore uma mensagem curta para meu professor pedindo uma reunião.`
4. Clique em **Terminar fala**.

## 6. Ensinar coisas sobre você

Digite no chat:

```text
/lembrar curso Engenharia de Software e uso C# na faculdade
/lembrar prefiro respostas curtas com exemplo de código
/memoria
```

Esses fatos ficam salvos em `dados/memoria.json` e vão junto em todas as conversas seguintes, mesmo depois de fechar o programa. Use `/esquecer 1` para remover um item e `/esquecer tudo` para limpar. Não guarde senhas nem chaves.

## 7. Preparar uma mensagem

1. Peça ao Jarvis para elaborar o texto.
2. Clique em **Preparar mensagem**.
3. Digite o número com país e DDD, por exemplo `5531999999999`.
4. Cole ou ajuste a mensagem.
5. Clique em **Preparar link**.
6. Revise e abra o rascunho no WhatsApp.
7. Pressione **Enviar** no próprio WhatsApp.

O envio não é automático; você sempre confirma destinatário e conteúdo.

## 8. Se a cota de voz terminar

1. Abra a engrenagem.
2. Mude **Modo de voz** para **Voz do sistema · sem cota de IA**.
3. Escolha uma voz em português instalada no Windows.
4. Clique em **Aplicar**.

A conversa por texto ainda depende da cota Gemini. Cálculos, data, hora, quadro e preparação do link do WhatsApp continuam funcionando localmente.

## 9. Cuidados

- Nunca publique sua chave em GitHub, vídeo, print ou mensagem.
- Use **Remover chave** antes de emprestar o computador.
- A chave fica apenas na memória e some ao encerrar o Jarvis.
- Na faixa gratuita, prompts, respostas, áudios e fotos enviados podem ser usados pelo Google para melhorar seus produtos.
- Não envie senhas, documentos sigilosos ou dados pessoais sensíveis.

## Links oficiais

- [Chaves da API Gemini](https://ai.google.dev/gemini-api/docs/api-key)
- [Faixa gratuita e faturamento](https://ai.google.dev/gemini-api/docs/billing)
- [Tabela de preços](https://ai.google.dev/gemini-api/docs/pricing)
- [Voz Gemini TTS](https://ai.google.dev/gemini-api/docs/speech-generation)
