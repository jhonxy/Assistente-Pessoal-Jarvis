# O que mudou nas versões 2.2 e 2.3

Revisão feita em 17/09/2026. Resumo para você lembrar depois por que cada coisa foi mexida.

## O problema que você estava vendo

A mensagem **"Modelo indisponível. Confira a disponibilidade dele no AI Studio"** não era erro da sua chave nem da sua conta.

O projeto pedia `gemini-2.5-flash-lite` e `gemini-2.5-flash`. O Google deixou de liberar a família Gemini 2.5 para chaves criadas recentemente: a API responde `404` dizendo que o modelo não está mais disponível para novos usuários. Chaves antigas seguem funcionando por herança de cota; chaves novas falham na primeira tentativa. A sua é nova, então caía exatamente nesse caso.

O formato da sua chave (`AQ.` em vez de `AIza`) **não** era o problema: ele funciona no endpoint nativo do Gemini, que é o que este projeto usa, enviando a chave no cabeçalho `x-goog-api-key`.

## Correções

| Mudança | Onde |
|---|---|
| Modelos de conversa atualizados para `gemini-3.5-flash-lite` (padrão), `gemini-3.6-flash` e `gemini-3.8-flash` | `core.py`, `web/index.html` |
| Modelo de voz atualizado para `gemini-3.1-flash-tts-preview` | `core.py` |
| Fallback automático: se o modelo escolhido tiver sido aposentado, o Jarvis tenta o próximo ativo e avisa qual passou a usar | `core.py`, `app.py` |
| Botão **Detectar modelos**: pergunta ao Google o que a sua chave aceita hoje e atualiza a lista | `app.py`, `web/app.js` |
| Erro de cota ou chave inválida continua falhando na hora, sem trocar de modelo e sem tentar serviço pago | `core.py` |
| Bloqueio de tarefa agora espera 0,75 s antes de recusar, em vez de recusar na hora | `app.py` |

As vozes Charon, Orus, Algenib e Algieba continuam válidas no modelo novo.

## Memória de longo prazo

Era o que faltava para o Jarvis "armazenar informações".

```text
/lembrar curso Engenharia de Software e uso C# na faculdade
/memoria
/esquecer 2
/esquecer tudo
```

Os fatos ficam em `dados/memoria.json`, sobrevivem ao fechamento do programa e são enviados à IA como parte da instrução do sistema em todas as conversas seguintes. Limite de 200 itens de 400 caracteres. O Jarvis só guarda o que você mandar guardar.

## Configurações que ficam salvas

Modelo, voz e modo de voz vão para `dados/config.json` automaticamente. Há uma opção nova, desmarcada por padrão, para salvar também a chave — aí o Jarvis abre já conectado. O arquivo recebe permissão restrita ao seu usuário, mas a chave fica em texto simples: só marque se o notebook for seu. **Remover chave** apaga tudo isso.

## Testes

- `py -3 -m unittest` — 31 testes (eram 18)
- `node test_frontend.cjs` — 12 fluxos (eram 9)

Novos casos cobertos: fallback de modelo aposentado, ausência de fallback em erro de cota ou chave inválida, listagem de modelos, comandos de memória, persistência entre reinícios, envio dos fatos ao modelo e gravação da preferência de chave.

Todos os testes usam respostas simuladas. **Nada foi testado contra a API real** — falta você validar no notebook: chave nova, microfone, câmera e reprodução de áudio.

## Versão 2.3 — sessão e provedor alternativo

### "Sessão inválida"

Não era problema de API. O serviço local protege os endpoints `/api/*` com um código de sessão que ia no endereço depois de `#token=`. Esse código era sorteado a cada execução e o navegador guardava em `sessionStorage`, que morre quando a janela fecha. Bastava reiniciar o programa, fechar a janela ou abrir o endereço sem a parte do token para tudo passar a dar 403.

O que mudou:

- o código de sessão agora fica em `dados/config.json` e é reaproveitado entre execuções;
- o navegador guarda em `localStorage`, que sobrevive ao fechamento da janela;
- ao receber 403 o Jarvis apaga o código velho e mostra o que fazer, em vez de uma falha genérica.

### Provedor NVIDIA

Dá para usar o catálogo NVIDIA NIM (`https://integrate.api.nvidia.com/v1`) no lugar do Gemini. Chave gratuita em build.nvidia.com, formato `nvapi-`, endpoint compatível com o da OpenAI.

Cobre conversa e elaboração de textos. **Não** cobre transcrição do microfone, voz de IA nem análise de foto — isso continua no Gemini, e o Jarvis avisa com clareza quando você tentar. A gratuidade também é diferente: a NVIDIA dá créditos limitados por conta com teto de requisições por minuto, enquanto o Gemini trabalha com cota que se renova.

Dá para deixar as duas chaves configuradas e alternar o provedor na engrenagem quando uma cota acabar.

## Pendências suas

1. Excluir no AI Studio a chave que apareceu no print e criar outra.
2. Abrir o Jarvis, colar a chave nova, clicar em **Aplicar** e depois em **Testar conexão**.
3. Se ainda der erro de modelo, clicar em **Detectar modelos**.
4. Testar `Ouvir teste`, o microfone e a câmera.
5. Opcional: criar a conta em build.nvidia.com se quiser o provedor alternativo.
