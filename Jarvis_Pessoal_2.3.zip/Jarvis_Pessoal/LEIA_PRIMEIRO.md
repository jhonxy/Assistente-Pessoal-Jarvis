# JARVIS 2.3 — edição pessoal do João

Assistente local com interface própria, conversa por texto e voz, memória de longo prazo, cálculos, elaboração de textos, análise de uma foto, quadro de ideias e preparação de mensagens para WhatsApp.

A aparência foi inspirada na referência enviada: fundo escuro, núcleo azul animado, câmera e painéis. É uma adaptação funcional, não o programa original do vídeo.

## Instalação rápida no Windows

1. Extraia todo o ZIP para uma pasta, por exemplo `Documentos\Jarvis`.
2. Instale [Python 3 para Windows](https://www.python.org/downloads/windows/). No instalador tradicional, marque **Add Python to PATH**.
3. Abra a pasta `Jarvis_Pessoal`.
4. Dê dois cliques em **Iniciar.bat**.
5. Mantenha a janela preta do terminal aberta enquanto usar o Jarvis.

Não é necessário instalar pacotes com `pip`, Node ou Visual Studio. O aplicativo usa apenas o Python padrão e recursos do Edge/Chrome.

O Jarvis tentará abrir uma janela própria do Edge ou Chrome. Se ela não aparecer, copie para o navegador o endereço exibido no terminal, começando por `http://127.0.0.1:`. O endereço contém um código temporário: não o compartilhe.

Faça primeiro um teste sem API:

```text
quanto é 25 vezes 4
```

A resposta esperada é `Resultado: 100`.

## Ativar gratuitamente o Gemini

O projeto usa o **Gemini 3.5 Flash-Lite** para conversa, áudio e fotos e o **Gemini 3.1 Flash TTS Preview** para a voz. Esses modelos possuem faixa gratuita, mas há limites de uso que podem mudar.

> **Mudança importante de setembro de 2026.** O Google parou de liberar a família **Gemini 2.5** para chaves criadas recentemente: elas respondem `404 — modelo indisponível`. Se você vir esse erro, não é problema da sua chave nem da sua conta. Abra as configurações e clique em **Detectar modelos**: o Jarvis pergunta ao Google o que a sua chave aceita hoje e ajusta a lista sozinho. O mesmo vale quando a família 3.5 for aposentada no futuro.

> As chaves novas do AI Studio começam com `AQ.` em vez de `AIza`. Esse formato funciona normalmente aqui, porque o Jarvis envia a chave no cabeçalho `x-goog-api-key` do endpoint nativo do Gemini.

1. Entre em [Google AI Studio — API Keys](https://aistudio.google.com/app/apikey) com sua conta Google.
2. Aceite os termos, caso sejam apresentados.
3. Confirme que o projeto aparece como **Free Tier**.
4. Use a chave criada automaticamente ou clique em **Create API key**.
5. Não clique em **Set up billing** se quiser permanecer somente na faixa gratuita.
6. Inicie o Jarvis e clique na **engrenagem**.
7. Marque **Ativar Gemini online**.
8. Cole a chave em **Chave da API do Google**.
9. Mantenha **Gemini 3.5 Flash-Lite · leve**.
10. Em **Modo de voz**, escolha **Voz Gemini · estilo assistente**.
11. Em **Voz Gemini**, escolha **Charon · informativa**.
12. Clique em **Aplicar** e depois em **Testar conexão**.
13. Se aparecer erro de modelo, clique em **Detectar modelos** e repita o teste.
14. Clique em **Ouvir teste** para conferir o áudio.

Por padrão a chave fica somente na memória do processo Python: não é salva no navegador nem nos arquivos do projeto, e ao encerrar o programa será necessário colá-la novamente.

Se preferir não repetir isso todo dia, marque **Salvar a chave neste computador** nas configurações. A chave passa a ficar em `dados/config.json`, em texto simples, com permissão restrita ao seu usuário. Só use essa opção se o notebook for seu; **Remover chave** apaga o arquivo e volta ao comportamento anterior. Como alternativa, usuários avançados podem definir a variável de ambiente `GEMINI_API_KEY`; ainda será preciso marcar a ativação online na interface.

Se a cota gratuita acabar, o Jarvis mostra o erro e não troca para um serviço pago. Aguarde a renovação da cota ou selecione **Voz do sistema**, que não usa a cota de voz Gemini. O aplicativo não ativa faturamento por conta própria.

> Importante sobre privacidade: segundo a tabela oficial de preços, entradas e respostas da faixa gratuita podem ser usadas pelo Google para melhorar seus produtos. Não envie senhas, documentos secretos ou dados pessoais sensíveis.

## Se aparecer "Sessão inválida"

Essa mensagem não tem relação com a API nem com a sua chave. O Jarvis protege o serviço local com um código de sessão que vai no endereço, depois do `#token=`. O erro aparece quando a janela do navegador está usando um código que não confere.

A partir da versão 2.3 o código fica guardado em `dados/config.json` e no navegador, então reiniciar o programa não invalida mais a janela aberta. Se mesmo assim acontecer:

1. Feche todas as janelas do Jarvis.
2. Rode o `Iniciar.bat` de novo.
3. Copie do terminal o endereço **inteiro**, incluindo a parte `#token=...`, e cole no Edge ou Chrome.

Não funciona salvar nos favoritos só `http://127.0.0.1:8765/`: sem o código na primeira visita o navegador não tem como se identificar. Se você apagou os dados de navegação do site, refaça os três passos acima.

## Usar a NVIDIA em vez do Google

A NVIDIA publica modelos abertos em [build.nvidia.com](https://build.nvidia.com) com uma API compatível com a da OpenAI. A conta é gratuita e não pede cartão; a chave começa com `nvapi-`.

1. Crie a conta e gere a chave em **Settings › API Keys**.
2. No Jarvis, abra a engrenagem e mude **Provedor de IA** para **NVIDIA NIM**.
3. Cole a chave, escolha o modelo e clique em **Aplicar**.
4. Clique em **Detectar modelos** para carregar o catálogo atual e depois em **Testar conexão**.

O que muda em relação ao Gemini:

| Recurso | Gemini | NVIDIA |
|---|---|---|
| Conversa e textos | Sim | Sim |
| Análise de foto | Sim | Não nesta versão |
| Transcrição do microfone | Sim | Não |
| Voz de IA | Sim | Não; use Voz do sistema |
| Tipo de gratuidade | Cota que renova | Créditos limitados por conta |

A diferença mais importante é a última. O Gemini trabalha com cotas que se renovam; a NVIDIA concede uma quantidade de créditos de inferência por conta, com limite de requisições por minuto, e você precisa pedir mais quando acabarem. Os limites atuais estão no próprio build.nvidia.com — confira lá, porque mudam.

Você pode manter as duas chaves configuradas e alternar o provedor quando a cota de uma acabar. Cálculos, memória, quadro e WhatsApp continuam funcionando sem nenhuma API.

## A voz estilo Jarvis

A opção recomendada é **Charon**, descrita pelo Google como uma voz informativa. O prompt pede tom calmo, preciso, elegante e levemente grave em português brasileiro.

Ela é uma voz sintética de assistente tecnológico. **Não é a voz original do personagem, do ator ou do dublador**, e o projeto não clona nenhuma pessoa real.

A voz Gemini lê até 1.500 caracteres de cada resposta. Para textos maiores, o Jarvis lê o início; selecione **Voz do sistema** se quiser ouvir o texto inteiro sem consumir a cota TTS.

## O que está incluído

| Recurso | Como usar | Usa internet/API |
|---|---|---|
| Interface própria | Núcleo central, chat, câmera e painéis | Não |
| Calculadora | `quanto é 25 vezes 4` ou `/calcular (25+15)*2` | Não |
| Memória | `/lembrar`, `/memoria` e `/esquecer` | Não |
| Data e hora | `/hora` ou `/data` | Não |
| Conversa e textos | Ative a IA (Gemini ou NVIDIA) e escreva o pedido | Sim |
| Microfone | **Falar** → fale → **Terminar fala** | Sim |
| Voz Gemini | **Ler respostas** ou **Ouvir** | Sim |
| Voz do sistema | Selecione na engrenagem | Não usa a API |
| Câmera | **Ligar câmera** para prévia local | Não |
| Análise visual | **Analisar foto** e depois **Enviar** | Sim, envia uma foto |
| Quadro de ideias | Crie cartões ou fixe respostas | Não |
| WhatsApp | Prepara um rascunho para sua revisão | Internet para abrir o WhatsApp |

## Memória de longo prazo

O Jarvis guarda no seu PC os fatos que você mandar lembrar e os envia à IA em todas as conversas seguintes.

```text
/lembrar curso Engenharia de Software e uso C# na faculdade
/lembrar prefiro explicações curtas com exemplo de código
/memoria
/esquecer 2
/esquecer tudo
```

Os fatos ficam em `dados/memoria.json`, até 200 itens de 400 caracteres cada. São guardados somente quando você usa `/lembrar` — o Jarvis não anota nada por conta própria. Já o histórico da conversa continua apenas na memória do processo e some ao encerrar ou ao usar **Limpar**.

Não guarde senhas, chaves ou documentos: o arquivo é texto simples e os fatos são enviados ao Google junto com as perguntas.

## Conversar por voz

1. Ative o Gemini nas configurações.
2. Deixe **Ler respostas** marcado.
3. Clique em **Falar** e permita o microfone.
4. Diga: `Jarvis, elabore uma mensagem curta pedindo uma reunião ao professor.`
5. Clique em **Terminar fala**.
6. O áudio será enviado ao Gemini para transcrição; depois a pergunta será respondida e lida.

Em **Conversa contínua**, o Jarvis detecta uma pausa, processa a fala, responde e volta a ouvir. Cada gravação dura no máximo 45 segundos. Esta versão trabalha por turnos; não fica ouvindo a palavra “Jarvis” em segundo plano e não é áudio simultâneo em tempo real.

Use **Parar voz** para interromper a leitura. **Pausar** também interrompe o microfone, desliga a câmera e remove a foto anexada. Uma solicitação já enviada pode terminar no provedor; pausar não desfaz o envio.

### Se a voz ou o microfone não funcionar

- Use Edge ou Chrome e aceite a permissão do microfone.
- Confira volume, saída de áudio e permissões do Windows.
- Teste a voz **Charon** na engrenagem.
- Se a cota TTS estiver indisponível, selecione **Voz do sistema**.
- Use fones para reduzir eco.
- Se a gravação não terminar sozinha, clique em **Terminar fala**.

## Mostrar uma foto pela câmera

1. Clique em **Ligar câmera** e permita o acesso.
2. Clique em **Analisar foto**.
3. Revise a pergunta, por exemplo: `O que aparece nesta imagem?`.
4. Clique em **Enviar**.

Somente a foto capturada é enviada ao Gemini, e apenas quando você confirma em **Enviar**. O aplicativo não transmite vídeo continuamente nem salva a foto.

## Preparar mensagem no WhatsApp

1. Clique em **Preparar mensagem**.
2. Digite país + DDD + número; no Brasil, comece por `55`.
3. Escreva ou cole a mensagem elaborada pelo Jarvis.
4. Clique em **Preparar link**.
5. Revise o número e o texto.
6. Clique em **Abrir rascunho no WhatsApp**.
7. Confirme o contato e pressione **Enviar** no próprio WhatsApp.

O Jarvis não envia mensagens automaticamente, não procura contatos pelo nome e não confirma entrega. Essa revisão evita mandar conteúdo ao destinatário errado.

## Organizar cartões

- Use **Fixar no quadro** abaixo de uma resposta.
- Abra **Quadro** no menu superior.
- Crie textos com **+ Texto** e importe fotos com **+ Imagem**.
- Arraste pelo título; use o lápis para editar e `×` para apagar.
- Aguarde **Salvo neste PC** antes de fechar.
- **Exportar** baixa um backup JSON.

O quadro é salvo em `dados/quadro.json`, aceita até 30 cartões e 4 MB. Imagens colocadas no quadro ficam locais e não são enviadas à API.

## Comandos para experimentar

```text
/calcular (25 + 15) * 2
/calcular 15% de 200
quanto é 25 vezes 4
/hora
/data
/whatsapp
/lembrar moro em Arniqueira, no Distrito Federal
/memoria
/ajuda
```

Com o Gemini ativo:

```text
Elabore uma mensagem curta pedindo uma reunião ao professor.
Deixe a mensagem mais informal.
Explique encapsulamento em C# de forma simples.
Crie um roteiro de estudo de POO para esta semana.
```

## Limites desta versão

O processamento de IA ocorre nos servidores do Google, portanto não baixa um modelo grande para os 8 GB de RAM do seu notebook. A interface e o serviço local são leves, mas câmera, microfone, conexão e programas abertos afetam a experiência.

Não estão incluídos: hologramas, reconhecimento de gestos, palavra de ativação em segundo plano, controle geral do Windows, execução de comandos, abertura automática de programas, agenda ou envio automático de mensagens. A IA também não vê sua tela nem a câmera sem uma foto anexada.

## Dados e segurança

- O serviço escuta apenas em `127.0.0.1`, no seu computador, e usa um código temporário de sessão.
- A chave não é devolvida ao navegador depois de configurada.
- O chat recente fica na memória e é apagado ao encerrar ou usar **Limpar**.
- Os fatos de `/lembrar` ficam em JSON local, sem criptografia, e acompanham as perguntas enviadas à IA.
- Até seis pares recentes de pergunta/resposta online podem ser enviados como contexto.
- Áudios e fotos não são gravados pelo aplicativo, mas são enviados ao Google quando você usa transcrição ou análise de foto.
- Cartões ficam em JSON local, sem criptografia.
- Respostas aparecem como texto e nunca são executadas como código.

## Arquivos principais

| Arquivo | Função |
|---|---|
| `Iniciar.bat` | Inicia no Windows |
| `PASSO_A_PASSO_GEMINI.md` | Guia curto de API e voz |
| `O_QUE_MUDOU.md` | O que foi corrigido na versão 2.2 |
| `app.py` | Serviço local e janela |
| `core.py` | Cálculos e integração Gemini |
| `web/` | Interface, aparência e interações |
| `test_core.py` e `test_server.py` | Testes Python |
| `test_frontend.cjs` | Testes opcionais da interface |
| `dados/quadro.json` | Cartões, criado no primeiro salvamento |
| `dados/memoria.json` | Fatos guardados com `/lembrar` |
| `dados/config.json` | Código de sessão, provedor, modelo, voz e, se você marcar, as chaves |

## Validação técnica

Para repetir os testes Python, abra um terminal na pasta e execute:

```text
py -3 -m unittest -v
```

São 31 testes Python e 12 fluxos JavaScript. Eles usam respostas simuladas e não consomem uma chave real. Também é possível executar `node test_frontend.cjs` se Node estiver instalado; Node não é necessário para usar o Jarvis.

Ainda é necessário testar no notebook o microfone físico, a câmera, a reprodução de áudio, uma chave Free Tier real e a conta do WhatsApp.

## Fontes oficiais

- [Criar e usar uma chave Gemini](https://ai.google.dev/gemini-api/docs/api-key)
- [Faixa gratuita e faturamento](https://ai.google.dev/gemini-api/docs/billing)
- [Preços e uso de dados](https://ai.google.dev/gemini-api/docs/pricing)
- [Modelos disponíveis](https://ai.google.dev/gemini-api/docs/models)
- [Modelos descontinuados](https://ai.google.dev/gemini-api/docs/deprecations)
- [Geração de voz e vozes disponíveis](https://ai.google.dev/gemini-api/docs/speech-generation)
- [Entrada e transcrição de áudio](https://ai.google.dev/gemini-api/docs/audio)
- [Python para Windows](https://www.python.org/downloads/windows/)
