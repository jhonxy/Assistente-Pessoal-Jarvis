import io
import json
import unittest
import urllib.error
from unittest.mock import patch
from core import (calculate, whatsapp_url, ask_ai, ask_ai_resilient, ask_nvidia,
                  list_models, list_nvidia_models, memory_command, memory_block,
                  ModelUnavailable)


class CoreTests(unittest.TestCase):
    def test_calculations(self):
        for text, result in [('(25+15)*2', '80'), ('15% de 200', '30'),
                             ('10,5 / 2', '5,25'), ('2^3', '8'), ('-5+2', '-3')]:
            self.assertEqual(calculate(text), result)

    def test_reject_unsafe_and_extreme_inputs(self):
        for text in ['__import__("os").system("echo bad")', '1/0', '2**100000',
                     '9**9**9', '1e309', '[1,2]', 'True', '(-1)^0.5', '1'*201]:
            with self.subTest(text=text), self.assertRaises(ValueError):
                calculate(text)

    def test_message_url(self):
        url = whatsapp_url('+55 (31) 99999-9999', 'Olá & tudo bem?')
        self.assertEqual(url, 'https://wa.me/5531999999999?text=Ol%C3%A1%20%26%20tudo%20bem%3F')
        for number, text in [('abc', 'Oi'), ('5531999999999', ''), ('1234', 'Oi')]:
            with self.assertRaises(ValueError):
                whatsapp_url(number, text)

    @patch('urllib.request.urlopen')
    def test_api_response_and_payload(self, request):
        request.return_value = io.BytesIO(json.dumps({'candidates': [
            {'content': {'parts': [{'text': 'Olá!'}]}, 'finishReason': 'STOP'}
        ]}).encode())
        self.assertEqual(ask_ai('test-key', 'gemini-3.5-flash-lite', [], 'Oi'), 'Olá!')
        req = request.call_args.args[0]
        payload = json.loads(req.data)
        self.assertEqual(payload['contents'], [{'role': 'user', 'parts': [{'text': 'Oi'}]}])
        self.assertTrue(req.full_url.startswith('https://generativelanguage.googleapis.com/'))
        self.assertNotIn('test-key', req.full_url)
        self.assertEqual(req.get_header('X-goog-api-key'), 'test-key')
        self.assertIsNone(req.get_header('Authorization'))

    @patch('urllib.request.urlopen')
    def test_api_error(self, request):
        request.side_effect = urllib.error.HTTPError('test', 401, '', {}, None)
        with self.assertRaisesRegex(ValueError, 'Chave Google inválida'):
            ask_ai('test', 'gemini-3.5-flash-lite', [], 'Oi')

    @patch('urllib.request.urlopen')
    def test_quota_does_not_retry_or_switch_provider(self, request):
        request.side_effect = urllib.error.HTTPError('test', 429, '', {}, None)
        with self.assertRaisesRegex(ValueError, 'cota'):
            ask_ai('test', 'gemini-3.5-flash-lite', [], 'Oi')
        self.assertEqual(request.call_count, 1)

    @patch('urllib.request.urlopen')
    def test_retired_model_falls_back_to_active_one(self, request):
        ok = json.dumps({'candidates': [{'content': {'parts': [{'text': 'Pronto.'}]}}]}).encode()
        request.side_effect = [urllib.error.HTTPError('t', 404, '', {}, None), io.BytesIO(ok)]
        answer, used = ask_ai_resilient('k', 'gemini-2.5-flash', [], 'Oi')
        self.assertEqual((answer, used), ('Pronto.', 'gemini-3.5-flash-lite'))

    @patch('urllib.request.urlopen')
    def test_no_fallback_on_quota_or_bad_key(self, request):
        for code, word in [(429, 'cota'), (401, 'inválida')]:
            request.reset_mock()
            request.side_effect = urllib.error.HTTPError('t', code, '', {}, None)
            with self.subTest(code=code), self.assertRaisesRegex(ValueError, word):
                ask_ai_resilient('k', 'gemini-3.5-flash-lite', [], 'Oi')
            self.assertEqual(request.call_count, 1)

    @patch('urllib.request.urlopen')
    def test_list_models_filters_to_supported(self, request):
        request.return_value = io.BytesIO(json.dumps({'models': [
            {'name': 'models/gemini-3.6-flash', 'supportedGenerationMethods': ['generateContent']},
            {'name': 'models/gemini-3.5-flash-lite', 'supportedGenerationMethods': ['generateContent']},
            {'name': 'models/veo-3.1-generate-preview', 'supportedGenerationMethods': ['predict']},
        ]}).encode())
        self.assertEqual(list_models('k'), ['gemini-3.5-flash-lite', 'gemini-3.6-flash'])
        self.assertNotIn('k', request.call_args.args[0].full_url)

    def test_memory_commands_and_prompt_block(self):
        self.assertEqual(memory_command('/lembrar Curso é Engenharia de Software.'),
                         ('add', 'Curso é Engenharia de Software'))
        self.assertEqual(memory_command('/memoria'), ('list', None))
        self.assertEqual(memory_command('/esquecer 2'), ('forget', 2))
        self.assertEqual(memory_command('/esquecer tudo'), ('forget', 'all'))
        self.assertIsNone(memory_command('quanto é 2 mais 2'))
        with self.assertRaises(ValueError):
            memory_command('/esquecer o primeiro')
        self.assertIn('Curso', memory_block(['Curso é Engenharia de Software']))
        self.assertEqual(memory_block([]), '')

    @patch('urllib.request.urlopen')
    def test_facts_reach_the_system_instruction(self, request):
        request.return_value = io.BytesIO(json.dumps({'candidates': [
            {'content': {'parts': [{'text': 'Ok.'}]}}]}).encode())
        ask_ai('k', 'gemini-3.5-flash-lite', [], 'Oi', None, ['Mora em Arniqueira'])
        payload = json.loads(request.call_args.args[0].data)
        self.assertIn('Mora em Arniqueira', payload['systemInstruction']['parts'][0]['text'])

    @patch('urllib.request.urlopen')
    def test_nvidia_uses_openai_shape_with_bearer_key(self, request):
        request.return_value = io.BytesIO(json.dumps({'choices': [
            {'message': {'role': 'assistant', 'content': 'Olá!'}, 'finish_reason': 'stop'}]}).encode())
        answer = ask_nvidia('nvapi-teste', 'meta/llama-3.3-70b-instruct',
                            [{'role': 'user', 'content': 'Oi'}], 'Tudo bem?', ['Mora em Arniqueira'])
        self.assertEqual(answer, 'Olá!')
        req = request.call_args.args[0]
        self.assertEqual(req.full_url, 'https://integrate.api.nvidia.com/v1/chat/completions')
        self.assertEqual(req.get_header('Authorization'), 'Bearer nvapi-teste')
        self.assertNotIn('nvapi-teste', req.full_url)
        body = json.loads(req.data)
        self.assertEqual(body['messages'][0]['role'], 'system')
        self.assertIn('Arniqueira', body['messages'][0]['content'])
        self.assertEqual(body['messages'][-1], {'role': 'user', 'content': 'Tudo bem?'})
        self.assertFalse(body['stream'])

    @patch('urllib.request.urlopen')
    def test_nvidia_credit_error_is_explained(self, request):
        request.side_effect = urllib.error.HTTPError('t', 429, '', {}, None)
        with self.assertRaisesRegex(ValueError, 'créditos gratuitos da NVIDIA'):
            ask_nvidia('nvapi-teste', 'meta/llama-3.3-70b-instruct', [], 'Oi')
        self.assertEqual(request.call_count, 1)

    @patch('urllib.request.urlopen')
    def test_nvidia_catalog_listing(self, request):
        request.return_value = io.BytesIO(json.dumps({'data': [
            {'id': 'meta/llama-3.3-70b-instruct'}, {'id': 'nvidia/nemotron-3-ultra'}]}).encode())
        self.assertEqual(list_nvidia_models('nvapi-teste'),
                         ['meta/llama-3.3-70b-instruct', 'nvidia/nemotron-3-ultra'])


if __name__ == '__main__':
    unittest.main()
